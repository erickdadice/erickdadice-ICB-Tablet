package com.pernix.icanbuy.models;

import junit.framework.TestCase;

public class ProductTest extends TestCase{

    public void testCreateProduct(){
        Product product= new Product("1235", "Atún Sardimar", "Atún sardimar individual", 1500.0);
        assertNotNull(product);
    }

    public void testCheckProductData(){
        Product product= new Product("1235", "Atún Sardimar", "Atún sardimar individual", 1500.0);
        assertEquals(product.getCode(), "1235");
        assertEquals(product.getName(), "Atún Sardimar");
        assertEquals(product.getDescription(), "Atún sardimar individual");
        assertEquals(product.getPrice(), 1500.0);
    }
}
