package com.pernix.icanbuy.services;

import android.test.ActivityInstrumentationTestCase2;

import com.pernix.icanbuy.activities.CartActivity;

import org.junit.Test;

public class XmlPostServiceTest extends ActivityInstrumentationTestCase2<CartActivity> {

    private final String XML_FILE = "<billingRequest> " +
                                "<cart> <cartItem> <product> " +
                                "<code>00xxx000000000020</code> <description>cavity protection, 130g</description> " +
                                "<name>Pasta Colgate</name> <price>1300.0</price> </product> <quantity>1</quantity> " +
                                "<total>1300.0</total> </cartItem> <cartTotal>1200.0</cartTotal> </cart> " +
                                "<email>icanbuyinfo@gmail.com</email></billingRequest>";

    public XmlPostServiceTest(Class<CartActivity> activityClass) {
        super(activityClass);
    }

    public XmlPostServiceTest() {
        super(CartActivity.class);
    }

    @Test
    public void testXmlPostServiceInstance(){
        XmlPostService xmlPostService = new XmlPostService(getActivity().getApplicationContext(), "");
        assertNotNull(xmlPostService);
    }

    @Test
    public void testPostXML(){
        XmlPostService xmlPostService = new XmlPostService(getActivity().getApplicationContext(), XML_FILE);
        assertEquals("Invoice was sent!", xmlPostService.postXMLBilling(XML_FILE));
    }

}
