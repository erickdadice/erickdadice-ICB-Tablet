package com.pernix.icanbuy.activities;

import android.app.Instrumentation;
import android.test.ActivityInstrumentationTestCase2;
import android.test.TouchUtils;
import android.widget.Button;

import com.pernix.icanbuy.R;

public class MainActivityTest extends ActivityInstrumentationTestCase2<MainActivity> {

    private Button buttonStartCart;

    public MainActivityTest(Class<MainActivity> activityClass) {
        super(activityClass);
    }

    public MainActivityTest(){
        super(MainActivity.class);
    }

    @Override
    protected void setUp(){
        buttonStartCart = (Button)getActivity().findViewById(R.id.button_start_cart);
    }

    public void testActivityNotNull(){
        assertNotNull(getActivity());
    }

    public void testButtonInitialization(){
        assertNotNull(buttonStartCart);
    }

    public void testIntentToProductList(){
        Instrumentation.ActivityMonitor activityMonitor = getInstrumentation().addMonitor(CartActivity.class.getName(), null, false);
        TouchUtils.clickView(this, buttonStartCart);
        CartActivity cartActivity= (CartActivity)activityMonitor.waitForActivity();
        assertNotNull(cartActivity);

    }



}