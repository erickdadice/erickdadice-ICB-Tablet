package com.pernix.icanbuy.presenters;

import android.test.ActivityInstrumentationTestCase2;

import com.pernix.icanbuy.activities.CartActivity;
import com.pernix.icanbuy.services.DALService;

public class CartPresenterTest  extends ActivityInstrumentationTestCase2<CartActivity> {

    private DALService firebaseService;

    public CartPresenterTest(Class<CartActivity> activityClass) {
        super(activityClass);
    }

    public CartPresenterTest(){
        super(CartActivity.class);
    }

    @Override
    protected void setUp() throws Exception
    {
        super.setUp();
        firebaseService= new DALService(getActivity().getApplication());
    }

    public void testGetProductFromFirebase(){
        CartPresenter cartPresenter= new CartPresenter(firebaseService, getActivity().getApplicationContext());
        assertNotNull(cartPresenter);
    }

    public void testCartHasItems(){
        CartPresenter cartPresenter= new CartPresenter(firebaseService, getActivity().getApplicationContext());
        assertEquals(cartPresenter.cartHasItems(), false);
    }

    public void testCartTotal(){
        CartPresenter cartPresenter= new CartPresenter(firebaseService, getActivity().getApplicationContext());
        assertEquals(cartPresenter.getCartTotal(), 0.0);
    }

}
