package com.pernix.icanbuy.utils;

import android.test.ActivityInstrumentationTestCase2;

import com.pernix.icanbuy.activities.CartActivity;
import com.pernix.icanbuy.models.Cart;
import com.pernix.icanbuy.models.CartItem;
import com.pernix.icanbuy.models.Product;
import com.pernix.icanbuy.models.BillingRequest;

import java.io.IOException;
import java.util.HashMap;

class XmlUtilTest extends ActivityInstrumentationTestCase2<CartActivity> {

    public XmlUtilTest(Class<CartActivity> activityClass) {
        super(activityClass);
    }

    public XmlUtilTest() {
        super(CartActivity.class);
    }

    public void testXMLInstance(){
        XmlUtil util= new XmlUtil(getActivity().getApplicationContext());
        assertNotNull(util);
    }

    public void testWriteXMLFile() throws IOException {
        Product product = new Product("1323", "Coca Cola", "500 ml", 800.00);
        CartItem cartItem = new CartItem(product, 2);

        Product product2 = new Product("4513", "Botella de agua", "600 ml", 500.00);
        CartItem cartItem2 = new CartItem(product2, 2);

        HashMap<String, CartItem> cartItems = new HashMap<>();
        cartItems.put(product.getCode(), cartItem);
        cartItems.put(product2.getCode(), cartItem2);

        Cart cart = new Cart(cartItems);
        BillingRequest request = new BillingRequest(cart, "johnny.xu@gmail.com");
        XmlUtil util= new XmlUtil(getActivity().getApplicationContext());
        String message = util.writeXMLFile(request);
        assertFalse(message.equals(""));
    }

    public void testWriteFileNotNull(){
        Product product2= new Product("85341", "Atún Tesoro del Mar", "500g", 1000.00);
        CartItem cartItem2= new CartItem(product2, 2);
        HashMap<String, CartItem> cartItems2= new HashMap<>();
        cartItems2.put(product2.getCode(), cartItem2);
    }
}
