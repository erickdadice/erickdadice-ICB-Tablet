package com.pernix.icanbuy.models;

import junit.framework.TestCase;

public class ProductListTest  extends TestCase {

    public void testCreateProductList(){
        ProductList productList= new ProductList();
        assertNotNull(productList);
    }

    public void testGetProduct(){
        Product product= new Product("1235", "Atún Sardimar", "Atún sardimar individual", 1500.0);
        ProductList productList= new ProductList();
        productList.addProduct(product);
        assertNotNull(productList.getProduct("1235"));

    }

    public void testAddProduct(){
        Product firstProduct= new Product("1235", "Atún Sardimar", "Atún sardimar individual", 1500.0);
        Product secondProduct= new Product("56341", "Atún Tesoro del mar", "Atún tesoro del mar individual", 1500.0);
        ProductList productList= new ProductList();
        productList.addProduct(firstProduct);
        productList.addProduct(secondProduct);
        assertNotNull(productList.getProduct("1235"));
        assertNotNull(productList.getProduct("56341"));
    }
}
