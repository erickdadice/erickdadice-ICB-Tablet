package com.pernix.icanbuy.activities;

import android.test.ActivityInstrumentationTestCase2;

import com.pernix.icanbuy.R;

public class CartActivityTest extends ActivityInstrumentationTestCase2<CartActivity> {

    public CartActivityTest(Class<CartActivity> activityClass) {
        super(activityClass);
    }

    public CartActivityTest(){
        super(CartActivity.class);
    }

    public void testActivityIsNotNull(){
        assertNotNull(getActivity());
    }

    public void testEmptyFragment() {
        assertNull(getActivity().getFragmentManager().findFragmentById(R.id.empty_list_fragment));
    }
}
