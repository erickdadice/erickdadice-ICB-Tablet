package com.pernix.icanbuy.utils;

import android.test.ActivityInstrumentationTestCase2;

import com.pernix.icanbuy.activities.MainActivity;

public class PropertiesConfigTest extends ActivityInstrumentationTestCase2<MainActivity> {

    public static final String FIREBASE_URL = "fireBaseURL";
    public static final String FIREBASE = "firebase";
    public static final String ICANBUY_FIREBASEIO_URL = "https://icanbuy.firebaseio.com";

    public PropertiesConfigTest(Class<MainActivity> activityClass) {
        super(activityClass);
    }

    public PropertiesConfigTest(){
        super(MainActivity.class);
    }

    public void testActivityExists(){
        assertNotNull(getActivity());
    }

    public void testCreatePropertiesConfig(){
        PropertiesConfig propertiesConfig= new PropertiesConfig(getActivity().getApplicationContext());
        assertNotNull(propertiesConfig);
    }

    public void testGetPropertyExists(){
        PropertiesConfig propertiesConfig= new PropertiesConfig(getActivity().getApplicationContext());
        assertNotNull(propertiesConfig.getProperty(FIREBASE_URL));
    }

    public void testGetPropertyDoesntExists(){
        PropertiesConfig propertiesConfig= new PropertiesConfig(getActivity().getApplicationContext());
        assertEquals("null", propertiesConfig.getProperty(FIREBASE));
    }

    public void testGetFirebaseURL(){
        PropertiesConfig propertiesConfig= new PropertiesConfig(getActivity().getApplicationContext());
        assertEquals(propertiesConfig.getFirebaseURL(), ICANBUY_FIREBASEIO_URL);
    }

}
