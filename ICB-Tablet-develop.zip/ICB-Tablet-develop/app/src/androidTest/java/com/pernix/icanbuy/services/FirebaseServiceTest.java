package com.pernix.icanbuy.services;

import android.test.ActivityInstrumentationTestCase2;

import com.pernix.icanbuy.activities.MainActivity;
import com.pernix.icanbuy.models.Product;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class FirebaseServiceTest extends ActivityInstrumentationTestCase2<MainActivity> {

    DALService firebaseService;

    public FirebaseServiceTest(Class<MainActivity> activityClass) {
        super(activityClass);
    }
    public FirebaseServiceTest(){
        super(MainActivity.class);
    }

    @Override
    protected void setUp() throws Exception
    {
        super.setUp();
        firebaseService= new DALService(getActivity().getApplication());
    }

    public void testActivityExists() {
        assertNotNull(getActivity());
    }

    public void testFireBaseRef(){
        assertNotNull(firebaseService);
    }

    public void testOneProduct()throws InterruptedException {
        CountDownLatch lock= new CountDownLatch(1);
        lock.await(5, TimeUnit.SECONDS);
        Product product= firebaseService.getProductByCode("0000000000000040");
        assertEquals(product.getName(), "Coca Cola");
        assertEquals(product.getCode(), "0000000000000040");
        assertEquals(product.getPrice(), 1000.0);
        assertEquals(product.getDescription(), "medio litro");
    }

    public void testAllProducts()throws InterruptedException {
        CountDownLatch lock= new CountDownLatch(1);
        lock.await(5, TimeUnit.SECONDS);
        assertNotNull(firebaseService.getProductByCode("0000000000000040"));
        assertNotNull(firebaseService.getProductByCode("0000000000000020"));
        assertNotNull(firebaseService.getProductByCode("0000000000000030"));
        assertNotNull(firebaseService.getProductByCode("0000000000000010"));
        assertNotNull(firebaseService.getProductByCode("48946"));
        assertNotNull(firebaseService.getProductByCode("56460"));
        assertNotNull(firebaseService.getProductByCode("78456"));
        assertNotNull(firebaseService.getProductByCode("89496"));
        assertNotNull(firebaseService.getProductByCode("49496"));
        assertNotNull(firebaseService.getProductByCode("5456"));
    }

    public void testProductDoesntExist(){
        assertNull(firebaseService.getProductByCode("gadgasg"));
    }

}
