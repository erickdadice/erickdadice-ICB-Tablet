package com.pernix.icanbuy.constants;

/**
 * Created by Roberto on 10/13/2015.
 */
public class BluetoothState {
    public static final int STATE_NONE = 0;       // we're doing nothing
    public static final int STATE_CONNECTING = 1; // now initiating an outgoing connetion
    public static final int STATE_CONNECTED = 2;  // now connected to a remote device
}
