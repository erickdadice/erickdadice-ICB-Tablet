package com.pernix.icanbuy.models.Factura;

import com.pernix.icanbuy.models.Product;

import java.util.HashMap;

public class FacturaList {
    private HashMap<String, Factura> facturaList;

    public FacturaList(){
        facturaList = new HashMap<String, Factura>();
    }

    public FacturaList(HashMap<String, Factura> productList) {
        this.facturaList = facturaList;
    }

    public void setFacturaList(HashMap<String, Factura> facturaList) {
        this.facturaList = facturaList;
    }

    public HashMap<String, Factura> getfacturaList() {
        return facturaList;
    }

    public void addFactura(Factura factura){
        facturaList.put(String.valueOf(factura.getIdFactura()), factura);
    }
    public Factura getFactura(String code){
        return facturaList.get(code);
    }
}
