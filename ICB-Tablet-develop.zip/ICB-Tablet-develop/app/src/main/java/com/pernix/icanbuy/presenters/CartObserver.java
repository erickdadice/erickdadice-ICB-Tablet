package com.pernix.icanbuy.presenters;

import com.pernix.icanbuy.models.CartItem;

public interface CartObserver {

    public void notifyNewProduct(CartItem item);

    public void notifyUpdateProduct();

    public void notifyFirstTime(CartItem cartItem);

    public void notifyRemoveProduct(CartItem cartItem);

}
