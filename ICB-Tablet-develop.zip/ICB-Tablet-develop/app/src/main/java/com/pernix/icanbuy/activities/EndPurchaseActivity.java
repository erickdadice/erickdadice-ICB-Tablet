package com.pernix.icanbuy.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.pernix.icanbuy.R;


public class EndPurchaseActivity extends Activity {

    public static final String EMAIL_CUSTOMER = "emailCustomer";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end_purchase);

        Intent intentGetEmail = getIntent();
        Bundle bundleEmail = intentGetEmail.getExtras();
        String mailCustomer = bundleEmail.getString(EMAIL_CUSTOMER);
        TextView emailCustomer = (TextView) findViewById(R.id.textEmailSent);
        String mail = getResources().getString(R.string.message_notification_mail);
        emailCustomer.setText(mail + " " + String.valueOf(mailCustomer));

        Button restartToPurchaseAgain = (Button) findViewById(R.id.restartButton);
        restartToPurchaseAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchToMainActivity();
            }
        });
    }

    public void switchToMainActivity(){
        Intent intentMain = new Intent(this, MainActivity.class);
        intentMain.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intentMain);
    }
}
