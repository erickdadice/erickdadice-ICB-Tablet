package com.pernix.icanbuy.pagos;

import android.widget.Toast;

import com.ingenico.connect.gateway.sdk.client.android.sdk.asynctask.BasicPaymentItemsAsyncTask;
import com.ingenico.connect.gateway.sdk.client.android.sdk.model.AmountOfMoney;
import com.ingenico.connect.gateway.sdk.client.android.sdk.model.CountryCode;
import com.ingenico.connect.gateway.sdk.client.android.sdk.model.CurrencyCode;
import com.pernix.icanbuy.activities.PaymentActivity;
import com.pernix.icanbuy.models.Cart;

public class PaymentContext {
    Cart cart = new Cart();

    double amountValue = cart.getCartTotal();
    CurrencyCode currencyCode = CurrencyCode.EUR;
    AmountOfMoney amountOfMoney = new AmountOfMoney((long) amountValue, currencyCode);
    CountryCode countryCode  = CountryCode.NL;
    Boolean isRecurring  = false;

    // Crear el PaymentContext
    PaymentContext paymentContext = new PaymentContext(amountOfMoney, countryCode, isRecurring);

    // Create listener for the BasicPaymentItemsAsyncTask callback
   /* BasicPaymentItemsAsyncTask.OnBasicPaymentItemsCallCompleteListener listener = new BasicPaymentItemsAsyncTask.OnBasicPaymentItemsCallCompleteListener() {

        @Override
        public void onBasicPaymentItemsCallComplete(com.ingenico.connect.gateway.sdk.client.android.sdk.model.paymentproduct.BasicPaymentItems basicPaymentItems) {
            if (basicPaymentItems == null) {
                Toast.makeText(PaymentContext.this, "Error", Toast.LENGTH_LONG).show();
            } else {
                // Allow the customer to select a payment product and an optional
                // account on file from the list of payment products
                // represented by paymentProducts.
            }
        }

    };*/

    // Get the Android application context, which is used to send device information
// in the request, which in turn is used to determine the validity of certain payment products
   // Context androidContext = getApplicationContext();

    // Indicate whether we want a BasicPaymentItems object that includes groups,
// or just contains basic payment products
    boolean groupPaymentProducts = true;

    public PaymentContext(AmountOfMoney amountOfMoney, CountryCode countryCode, Boolean isRecurring) {
    }

// Do the paymentproducts lookup
//session.getBasicPaymentItems(androidContext, paymentContext, listener, groupPaymentProducts);
}
