package com.pernix.icanbuy.models.Carrito;

import java.util.HashMap;

public class CarritoList {
    private HashMap<String, Carrito> carritoList;

    public CarritoList(){
        carritoList = new HashMap<String, Carrito>();
    }

    public CarritoList(HashMap<String, Carrito> carritoList) { this.carritoList = carritoList; }

    public void setCarritoList(HashMap<String, Carrito> carritoList) { this.carritoList = carritoList; }

    public HashMap<String, Carrito> getCarritoList() { return carritoList; }

    public void addCarrito(Carrito carrito){
        carritoList.put(String.valueOf(carrito.getIdCarrito()), carrito);
    }

    public Carrito getCarrito(String id){
        return carritoList.get(id);
    }



}
