package com.pernix.icanbuy.models.DetalleFactura;


import java.util.HashMap;

public class DetalleFacturaList {
    private HashMap<String, DetalleFactura> detallefacturaList;

    public DetalleFacturaList(){
        detallefacturaList = new HashMap<String, DetalleFactura>();
    }

    public DetalleFacturaList(HashMap<String, DetalleFactura> detallefacturaList) {
        this.detallefacturaList = detallefacturaList;
    }

    public void setDetallefacturaList(HashMap<String, DetalleFactura> detallefacturaListList) {
        this.detallefacturaList = detallefacturaList;
    }

    public HashMap<String, DetalleFactura> getDetallefacturaList() {
        return detallefacturaList;
    }

    public void addDetalleFactura(DetalleFactura detalleFactura){
        detallefacturaList.put(String.valueOf(detalleFactura.getIdDetalle()), detalleFactura);
    }
    public DetalleFactura getDetalleFactura(String code){
        return detallefacturaList.get(code);
    }
}
