package com.pernix.icanbuy.services;

import android.content.Context;
import android.os.AsyncTask;

import com.pernix.icanbuy.models.BillingResponse;
import com.pernix.icanbuy.utils.PropertiesConfig;
import com.pernix.icanbuy.utils.XmlUtil;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import java.net.URL;

public class XmlPostService extends AsyncTask<String, Integer, Double> {

    private Context context;
    private String xmlFile;
    private static final String MEDIA_TYPE = "application/xml; charset=utf-8";

    public XmlPostService(Context context, String xmlFile) {
        this.context = context;
        this.xmlFile = xmlFile;
    }


    public String postXMLBilling(String xmlFile) {
        OkHttpClient client = null;
        BillingResponse billingResponse = null;
        XmlUtil xmlUtil = new XmlUtil(context);
        try {

            PropertiesConfig propertiesConfig = new PropertiesConfig(context);

            String serverUrl = propertiesConfig.getServerUrl();
            URL url = new URL(serverUrl);

            client = new OkHttpClient();
            MediaType XmlContent = MediaType.parse(MEDIA_TYPE);

            RequestBody body = RequestBody.create(XmlContent, xmlFile);
            Request request = new Request.Builder()
                    .url(url)
                    .post(body)
                    .build();
            Response response = client.newCall(request).execute();
            String content = response.body().string();
            billingResponse = xmlUtil.readServerResponse(content);

            response.body().close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return billingResponse.getMessage();
    }


    @Override
    protected Double doInBackground(String... params) {
        postXMLBilling(xmlFile);
        return null;
    }

}
