package com.pernix.icanbuy.activities;

public interface AsyncTaskCallback {
    void onPostExecute(Object result);
}
