package com.pernix.icanbuy.models;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name= "billingResponse")
public class BillingResponse {

    @Element
    private String message;

    @Element
    private String status;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
