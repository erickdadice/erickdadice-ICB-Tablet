package com.pernix.icanbuy.models;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Root
public class Cart implements Serializable{

    private HashMap<Long, CartItem> cartItems;

    @ElementList(inline=true)
    private List<CartItem> itemList;

    @Element
    private double cartTotal;

    public Cart() {
        cartTotal = 0;
        cartItems = new HashMap<Long, CartItem>();
        itemList= new ArrayList<>();
    }

    public Cart(HashMap<Long, CartItem> cartItems) {
        this.cartItems = cartItems;
        this.itemList  = new ArrayList<CartItem>(cartItems.values());
        calculateTotal();

    }

    public double calculateTotal(){
        for (CartItem item : cartItems.values()){
            cartTotal = cartTotal + item.getTotal();
        }
        return cartTotal;
    }

    public double getCartTotal() {
        return cartTotal;
    }

    public void setCartTotal(double cartTotal) {
        this.cartTotal = cartTotal;
    }

    public int getCartSize(){
        return cartItems.size();
    }

    public CartItem getCartItemByCode(Long code){
        return cartItems.get(code);
    }

    public CartItem createNewItem(Product product){
        CartItem item = new CartItem(product, 1);
        cartItems.put(product.getIdProducto(),item);
        itemList.add(item);
        return item;
    }

    public void removeItem(CartItem item){
        System.out.println("Cantidad antes : " + item.getQuantity());
        item.setQuantity(item.getQuantity() - 1);
        if (item.getQuantity() == 0) {
            cartItems.remove(item.getProduct().getIdProducto());
            itemList.add(item);
        }
        System.out.println("Cantidad despues : " + item.getQuantity());
    }

    public void addItem(CartItem item){
        System.out.println("Cantidad antes : " + item.getQuantity());
        item.setQuantity(item.getQuantity() + 1);
        if (item.getQuantity() != 0) {
            cartItems.put(item.getProduct().getIdProducto(),item);
            itemList.add(item);
        }
        System.out.println("Cantidad despues : " + item.getQuantity());
    }

}
