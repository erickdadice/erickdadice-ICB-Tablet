package com.pernix.icanbuy.bluetooth.bluetoothThread;


/**
 * Created by Roberto on 10/13/2015.
 */

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.pernix.icanbuy.bluetooth.BluetoothDeviceConnector;
import com.pernix.icanbuy.utils.BluetoothUtil;
import java.io.IOException;

import static com.pernix.icanbuy.constants.BluetoothConstant.APPLICATION_NAME;
import static com.pernix.icanbuy.constants.BluetoothConstant.CONNECTION_FAILED;
import static com.pernix.icanbuy.constants.BluetoothConstant.MESSAGE_TOAST;
import static com.pernix.icanbuy.constants.BluetoothState.STATE_NONE;


/**
 * Stream class to connect to the BT-device
 */
public class ConnectThread extends Thread {
    private BluetoothAdapter bluetoothAdapter;
    private final BluetoothSocket mmSocket;
    private final BluetoothDevice mmDevice;
    private BluetoothDeviceConnector bluetoothDeviceConnector;
    private Handler finalHandler;
    private ConnectThread connectThread;

    public ConnectThread(BluetoothDevice device, BluetoothAdapter bluetoothAdapter,
                         BluetoothDeviceConnector bluetoothDeviceConnector, Handler finalHandler,
                         ConnectThread connectThread) {
        this.bluetoothAdapter = bluetoothAdapter;
        mmDevice = device;
        mmSocket = BluetoothUtil.createRfcommSocket(mmDevice);
        this.bluetoothDeviceConnector = bluetoothDeviceConnector;
        this.finalHandler = finalHandler;
        this.connectThread = connectThread;
    }

    /**
     * The basic working method to connect to the device.
     * When the connection is successful transfers control to another thread
     */
    public void run() {
        bluetoothAdapter.cancelDiscovery();
        if (mmSocket == null) {
            connectionFailed();
            return;
        }

        // Make a connection to the BluetoothSocket
        try {
            // This is a blocking call and will only return on a
            // successful connection or an exception
            mmSocket.connect();
        } catch (IOException e) {
            connectionFailed();
            return;
        }

        // Reset the ConnectThread because we're done
        synchronized (bluetoothDeviceConnector) {
            connectThread = null;
        }

        // Start the connected thread
        bluetoothDeviceConnector.connected(mmSocket);
    }

    private void connectionFailed() {
        Log.i(APPLICATION_NAME, CONNECTION_FAILED);
        Message msg = finalHandler.obtainMessage(MESSAGE_TOAST);
        Bundle bundle = new Bundle();
        msg.setData(bundle);
        finalHandler.sendMessage(msg);
        bluetoothDeviceConnector.setState(STATE_NONE);
    }
}