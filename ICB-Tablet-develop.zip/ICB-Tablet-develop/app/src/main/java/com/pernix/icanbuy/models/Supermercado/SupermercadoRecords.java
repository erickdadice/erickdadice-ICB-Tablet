package com.pernix.icanbuy.models.Supermercado;

import com.pernix.icanbuy.models.Carrito.CarritoRecord;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SupermercadoRecords {
    private List<SupermercadoRecord> records = null;
    private String offset;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public List<SupermercadoRecord> getRecords() {
        return records;
    }

    public void setRecords(List<SupermercadoRecord> records) {
        this.records = records;
    }

    public String getOffset() {
        return offset;
    }

    public void setOffset(String offset) {
        this.offset = offset;
    }

    public Map<String, Object> getAdditionalProperties() {
        return additionalProperties;
    }

    public void setAdditionalProperties(Map<String, Object> additionalProperties) {
        this.additionalProperties = additionalProperties;
    }
}
