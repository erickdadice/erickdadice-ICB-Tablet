package com.pernix.icanbuy.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterViewFlipper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pernix.icanbuy.R;
import com.pernix.icanbuy.adapter.ImageListAdapter;
import com.pernix.icanbuy.fragments.EmptyListFragment;
import com.pernix.icanbuy.fragments.ProductListFragment;
import com.pernix.icanbuy.models.Cart;
import com.pernix.icanbuy.models.CartItem;
import com.pernix.icanbuy.models.ConexionCarrito.ConexionCarritoRecord;
import com.pernix.icanbuy.models.ConexionCarrito.ConexionCarritoRecords;
import com.pernix.icanbuy.models.Factura.Factura;
import com.pernix.icanbuy.models.Factura.FacturaRecord;
import com.pernix.icanbuy.models.Factura.FacturaRecords;
import com.pernix.icanbuy.presenters.CartObserver;
import com.pernix.icanbuy.presenters.CartPresenter;
import com.pernix.icanbuy.services.BluetoothService;
import com.pernix.icanbuy.services.DALService;
import com.pernix.icanbuy.utils.PropertiesConfig;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class CartActivity extends FragmentActivity implements CartObserver, AsyncTaskCallback {

    public static final String CART_EMPTY_MESSAGE = "Por favor agregue un producto al carrito";
    public static final String CART_KEY = "cart";
    private CartPresenter presenter;
    private ProductListFragment productListFragment;
    private BluetoothService bluetoothService;
    private TextView textViewCartTotal;
    private AdapterViewFlipper informationPanel;
    private int[] images = {R.drawable.carnes, R.drawable.verduras};
    private String mCarrito;
    //botón de cancelar compra
    private Button btnCancelar;
    public static String totalCarrito;
    private EditText edt_product_code;
    private String codbar;
    private PropertiesConfig propertiesConfig;
    private String idUsuario;
    CartActivity context=this;
    private int idFactura;
    private Cart cart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DALService firebaseService = new DALService(this);
        presenter = new CartPresenter(firebaseService, this);
        setContentView(R.layout.activity_cart);
        informationPanel = (AdapterViewFlipper) findViewById(R.id.simpleAdapterViewFlipper);
        ImageListAdapter customAdapter = new ImageListAdapter(getApplicationContext(),images);
        informationPanel.setAdapter(customAdapter);
        informationPanel.setAutoStart(true);
        presenter.addObserver(this);
        textViewCartTotal = (TextView) findViewById(R.id.textview_cart_total);
        initializeFragment();
        bluetoothService = new BluetoothService(presenter, savedInstanceState, this);

        //this.mCarrito= this.getIntent().getStringExtra("ID_maestro_carrito");

        edt_product_code=(EditText)findViewById(R.id.edt_product_code);
        edt_product_code.setFocusableInTouchMode(true);
        edt_product_code.setFocusable(true);
        edt_product_code.requestFocus();
        codbar = edt_product_code.getText().toString();

        edt_product_code.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                (new Handler()).postDelayed(this::agregarACarrito, 3000);

                (new Handler()).postDelayed(this::borrarTexto, 7000);
            }
            private void agregarACarrito(){
                presenter.addCartItem(edt_product_code.getText().toString());
                new PostADetalleFactura().execute();
            }

            private void borrarTexto() {
                edt_product_code.setText(null);
            }
        });


        Button buttonPayment = (Button) findViewById(R.id.button_payment);
        buttonPayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(presenter.cartHasItems()){
                   getDatosTablet getDatosT = new getDatosTablet("1", context);
                  getDatosT.execute();

                    new PostAFactura().execute();

                    //(new Handler()).postDelayed(this::switchPaymentLayout, 4000);
                   //switchPaymentLayout();
                }else{
                    Toast.makeText(getApplicationContext(), CART_EMPTY_MESSAGE, Toast.LENGTH_LONG).show();
                }
            }

           /* private void switchPaymentLayout() {
                Intent intentPayment = new Intent(CartActivity.this, CualMetodoActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable(CART_KEY, presenter.getCart());
                intentPayment.putExtras(bundle);
                startActivity(intentPayment);
            }*/
        });
        btnCancelar= (Button) findViewById(R.id.button_cancelar);
        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });



    }

    private void borrarTexto(){
        edt_product_code.setText(null);
    }

    public CartPresenter getPresenter() {
        return this.presenter;
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        if (bluetoothService != null) {
            bluetoothService.finalize();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        bluetoothService.setBluetoothState(outState);
    }
/*
    public void addProduct(View v){

        final EditText input = new EditText(this);
        input.setVisibility(View.GONE);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_NUMBER);
        presenter.addCartItem(input.getText().toString());
    }*/

    public void addProduct2(String codigo){
        presenter.addCartItem(codigo);
    }

    public void addProduct(View v){
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Escanee el producto:");
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_CLASS_NUMBER);
        builder.setView(input);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                presenter.addCartItem(input.getText().toString());
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();

    }

    /*@Override
    public void onStart() {
        super.onStart();
        PropertiesConfig propertiesConfig= new PropertiesConfig(this);
        bluetoothService.initializeAdapter(propertiesConfig);
    }*/

   /* @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_product_list, menu);
        return true;
    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void initializeFragment() {
        FragmentTransaction fragmentTransaction= getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.datatable, new EmptyListFragment());
        fragmentTransaction.commit();
    }

    public void changeFragmentToProductList() {
        productListFragment = new ProductListFragment();
        FragmentTransaction fragmentTransaction= getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.datatable, productListFragment);
        fragmentTransaction.commit();
    }

    @Override
    public void notifyNewProduct(final CartItem item) {
        productListFragment.addProduct(item);
        textViewCartTotal.setText(String.valueOf(presenter.getCartTotal()));
        totalCarrito=String.valueOf(presenter.getCartTotal());
        MediaPlayer mp = MediaPlayer.create(this, R.raw.add_product);
        mp.start();

    }

    @Override
    public void notifyUpdateProduct() {
        productListFragment.notifyProductChange();
        textViewCartTotal.setText(String.valueOf(presenter.getCartTotal()));
        totalCarrito=String.valueOf(presenter.getCartTotal());
        MediaPlayer mp = MediaPlayer.create(this, R.raw.add_product);
        mp.start();
    }

    @Override
    public void notifyFirstTime(final CartItem cartItem) {
        changeFragmentToProductList();

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                productListFragment.addProduct(cartItem);
                textViewCartTotal.setText(String.valueOf(presenter.getCartTotal()));
                totalCarrito=String.valueOf(presenter.getCartTotal());
            }
        }, 2000);
        MediaPlayer mp = MediaPlayer.create(this, R.raw.add_product);
        mp.start();
    }

    @Override
    public void notifyRemoveProduct(final CartItem item) {
        if(item.getQuantity() == 0) {
            productListFragment.removeProduct(item);
        }
        textViewCartTotal.setText(String.valueOf(presenter.getCartTotal()));
        totalCarrito=String.valueOf(presenter.getCartTotal());
    }


    public void switchPaymentLayout(){
        Intent intentPayment = new Intent(this, CualMetodoActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable(CART_KEY, presenter.getCart());
        intentPayment.putExtras(bundle);
        startActivity(intentPayment);
    }




    @Override
    public void onPostExecute(Object result) {

        switchPaymentLayout();
    }

    public class PostAFactura extends AsyncTask<Void,Void, FacturaRecord>{

        @Override
        protected FacturaRecord doInBackground(Void... voids) {
            URL url2 = null;
            try {
                url2 = new URL(propertiesConfig.getAirtableBaseUrl()+"/Factura");

                HttpURLConnection http = (HttpURLConnection)url2.openConnection();
                http.setRequestMethod("POST");
                http.setDoOutput(true);
                http.setRequestProperty("Authorization", "Bearer "+ propertiesConfig.getAirtableApiKey());
                http.setRequestProperty("Content-Type", "application/json");

                JSONObject jsonObjectFields = new JSONObject();
                try{

                    jsonObjectFields.put("fields",datosF());
                }catch (Exception exception){
                    exception.printStackTrace();
                }

                byte[] out = jsonObjectFields.toString().getBytes(StandardCharsets.UTF_8);

                OutputStream stream = http.getOutputStream();
                stream.write(out);

                System.out.println(http.getResponseCode() + " " + http.getResponseMessage());
                http.disconnect();
            }catch(Exception e){
                e.printStackTrace();
            }
            return null;
        }//do in background
    }//async post Factura



    public class PostADetalleFactura extends AsyncTask<Void,Void, FacturaRecord>{

        @Override
        protected FacturaRecord doInBackground(Void... voids) {
            URL url2 = null;
            try {
                url2 = new URL(propertiesConfig.getAirtableBaseUrl()+"/ConexionCarrito");

                HttpURLConnection http = (HttpURLConnection)url2.openConnection();
                http.setRequestMethod("POST");
                http.setDoOutput(true);
                http.setRequestProperty("Authorization", "Bearer "+ propertiesConfig.getAirtableApiKey());
                http.setRequestProperty("Content-Type", "application/json");

                JSONObject jsonObjectFields = new JSONObject();
                try{

                    jsonObjectFields.put("fields",datosDF());
                }catch (Exception exception){
                    exception.printStackTrace();
                }

                byte[] out = jsonObjectFields.toString().getBytes(StandardCharsets.UTF_8);

                OutputStream stream = http.getOutputStream();
                stream.write(out);

                System.out.println(http.getResponseCode() + " " + http.getResponseMessage());
                http.disconnect();
            }catch(Exception e){
                e.printStackTrace();
            }
            return null;
        }//do in background
    }//async post


    private JSONObject datosF() throws JSONException {
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);

        JSONObject params = new JSONObject();
        params.put( "IdUsuario", idUsuario);
        params.put( "FechaCompra", today.getTime());
        params.put( "Total", totalCarrito);
        params.put( "IdSupermercado", "1");
        return params;
    }
    public Cart getCart() {
        return cart;
    }
    private JSONObject datosDF() throws JSONException {

        JSONObject params = new JSONObject();
        params.put( "IdFactura", idFactura);
        params.put( "IdProducto", edt_product_code.getText().toString());
        CartItem item = cart.getCartItemByCode(Long.valueOf(edt_product_code.getText().toString()));

        params.put( "CantidadComprada", item.getQuantity());
        params.put( "Precio", item.getProduct().getPrecio());
        return params;
    }





    public class getDatosTablet extends AsyncTask<Void, Void, ConexionCarritoRecord> {

        private String idtablet="1";
        public AsyncTaskCallback callback = null;

        public getDatosTablet(String idtablet, AsyncTaskCallback callback){
            this.callback = callback;
        }


        @Override
        protected ConexionCarritoRecord doInBackground(Void... voids) {
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(JsonParser.Feature.IGNORE_UNDEFINED, true);
            mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
            mapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
            mapper.configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true);
            MappingJackson2HttpMessageConverter messageConverter = new MappingJackson2HttpMessageConverter();
            messageConverter.setObjectMapper(mapper);
            List<HttpMessageConverter<?>> converters = new ArrayList<HttpMessageConverter<?>>();
            converters.add(messageConverter);
            HttpHeaders requestHeaders = new HttpHeaders();
            requestHeaders.set("Authorization", "Bearer " + Constants.AIRTABLE_API_KEY);
            RestTemplate restTemplate = new RestTemplate(true);
            for (int i = 0; i < restTemplate.getMessageConverters().size(); i++) {
                if (!restTemplate.getMessageConverters().get(i).getClass().getName().equals(MappingJackson2HttpMessageConverter.class.getName())) {
                    converters.add(restTemplate.getMessageConverters().get(i));
                }
            }
            restTemplate.setMessageConverters(converters);
            restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory());
            HttpEntity<?> httpEntity = new HttpEntity<Object>("", requestHeaders);

            String url = Constants.AIRTABLE_BASE_URL +
                    "ConexionCarrito?filterByFormula=IDTablet=1";

            Log.d("http", url);
            ResponseEntity<ConexionCarritoRecords> response = restTemplate.exchange(url, HttpMethod.GET, httpEntity, ConexionCarritoRecords.class);
            Log.d("http", response.getStatusCode().toString());

            if (response.getStatusCode() == HttpStatus.OK) {
                if (response.getBody().getRecords().size() > 0) {
                   for(ConexionCarritoRecord p: response.getBody().getRecords()){
                       idUsuario=p.getFields().getiDUsuario();
                   }

                    return response.getBody().getRecords().get(0);

                }
            }
            return null;
        }
        @Override
        protected void onPostExecute(ConexionCarritoRecord result) {
            if(callback != null) {
                callback.onPostExecute(result);
            }
            super.onPostExecute(result);
        }



    }//class get Datos Tablet

    public class getDatosFactura extends AsyncTask<Void, Void, FacturaRecord> {

        private String idtablet="1";
        public AsyncTaskCallback callback = null;

        public getDatosFactura(String idtablet, AsyncTaskCallback callback){
            this.callback = callback;
        }


        @Override
        protected FacturaRecord doInBackground(Void... voids) {
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(JsonParser.Feature.IGNORE_UNDEFINED, true);
            mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
            mapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
            mapper.configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true);
            MappingJackson2HttpMessageConverter messageConverter = new MappingJackson2HttpMessageConverter();
            messageConverter.setObjectMapper(mapper);
            List<HttpMessageConverter<?>> converters = new ArrayList<HttpMessageConverter<?>>();
            converters.add(messageConverter);
            HttpHeaders requestHeaders = new HttpHeaders();
            requestHeaders.set("Authorization", "Bearer " + Constants.AIRTABLE_API_KEY);
            RestTemplate restTemplate = new RestTemplate(true);
            for (int i = 0; i < restTemplate.getMessageConverters().size(); i++) {
                if (!restTemplate.getMessageConverters().get(i).getClass().getName().equals(MappingJackson2HttpMessageConverter.class.getName())) {
                    converters.add(restTemplate.getMessageConverters().get(i));
                }
            }
            restTemplate.setMessageConverters(converters);
            restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory());
            HttpEntity<?> httpEntity = new HttpEntity<Object>("", requestHeaders);

            String url = Constants.AIRTABLE_BASE_URL +
                    "Factura?filterByFormula=IdUsuario="+idUsuario;

            Log.d("http", url);
            ResponseEntity<FacturaRecords> response = restTemplate.exchange(url, HttpMethod.GET, httpEntity, FacturaRecords.class);
            Log.d("http", response.getStatusCode().toString());

            if (response.getStatusCode() == HttpStatus.OK) {
                if (response.getBody().getRecords().size() > 0) {
                    for(FacturaRecord p: response.getBody().getRecords()){
                        idFactura=p.getFields().getIdFactura();
                    }

                    return response.getBody().getRecords().get(0);

                }
            }
            return null;
        }
        @Override
        protected void onPostExecute(FacturaRecord result) {
            if(callback != null) {
                callback.onPostExecute(result);
            }
            super.onPostExecute(result);
        }



    }//class get Datos Factura
}//activity
