package com.pernix.icanbuy.models;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

import java.io.Serializable;

@Root(strict=false)
public class CartItem implements Serializable{

    @Element
    private Product product;
    @Element
    private int quantity;
    @Element
    private double total;

    public CartItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
        setTotal();
    }

    public CartItem() {
    }

    public Product getProduct() {

        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
        setTotal();
    }

    public double getTotal() {
        return total;
    }

    private void setTotal() {

        this.total = quantity * product.getPrecio();
    }
}
