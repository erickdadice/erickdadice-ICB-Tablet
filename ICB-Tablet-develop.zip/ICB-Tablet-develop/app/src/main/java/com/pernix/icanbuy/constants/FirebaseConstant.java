package com.pernix.icanbuy.constants;

public final class FirebaseConstant {
    public final static String APPLICATION_TAG= "ICanBuy";
    public final static String INITIALIZE_PROPERTIES_ERROR_MESSAGE= "Error at initializeProperties()";
}
