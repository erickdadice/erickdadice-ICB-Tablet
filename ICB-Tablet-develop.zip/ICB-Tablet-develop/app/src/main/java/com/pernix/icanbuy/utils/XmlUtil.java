package com.pernix.icanbuy.utils;

import android.content.Context;
import android.util.Log;

import com.pernix.icanbuy.models.BillingRequest;
import com.pernix.icanbuy.models.BillingResponse;

import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class XmlUtil {

    private Context context;
    private static final String FILE_NAME = "\\file.xml";

    public XmlUtil(Context context){
        this.context = context;
    }

    public String writeXMLFile(BillingRequest request) throws IOException {
        Serializer serializer = new Persister();
        File xmlFile = new File(context.getFilesDir() + FILE_NAME);
        String result= null;
        createFileIfDoesntExists(xmlFile);
        try {
            serializer.write(request, xmlFile);
            result =  readText(xmlFile);
        } catch (Exception e) {
            Log.e("ICanBuy", e.getMessage());
        }

        return result;
    }

    private void createFileIfDoesntExists(File xmlFile) throws IOException {
        if(!xmlFile.exists()) {
            xmlFile.createNewFile();
        }
    }

    public String readText(File file) throws IOException {
        final InputStream inputStream = new FileInputStream(file);
        final BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        final StringBuilder stringBuilder = new StringBuilder();
        boolean done = false;

        while (!done) {
            final String line = reader.readLine();

            if(line == null){
                done = true;
            }

            if (line != null) {
                stringBuilder.append(line);
            }
        }
        reader.close();
        inputStream.close();

        return stringBuilder.toString();
    }

    public BillingResponse readServerResponse(String responseXML){
        Serializer serializer = new Persister();
        BillingResponse billingResponse = null;
        try {
             billingResponse = serializer.read(BillingResponse.class, responseXML);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return billingResponse;
    }

}