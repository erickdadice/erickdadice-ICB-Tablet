package com.pernix.icanbuy.utils;

import android.graphics.Bitmap;
import android.util.Log;

/**
 * Created by Roberto on 10/23/2015.
 */
public class BlurUtil {

    public Bitmap fastBlur(Bitmap sentBitmap, int radius) {
        Bitmap bitmap = sentBitmap.copy(sentBitmap.getConfig(), true);

        if (radius < 1) {
            return (null);
        }

        int width = bitmap.getWidth();
        int height = bitmap.getHeight();

        int[] pixels = new int[width * height];
        Log.e("pixels", width + " " + height + " " + pixels.length);
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);

        int wm = width - 1;
        int hm = height - 1;
        int wh = width * height;
        int div = radius + radius + 1;

        int redColor[] = new int[wh];
        int greenColor[] = new int[wh];
        int blueColor[] = new int[wh];
        int redSum, greenSum, blueSum, x, y, i, p, yp, yi, yw;
        int vmin[] = new int[Math.max(width, height)];

        int divsum = (div + 1) >> 1;
        divsum *= divsum;
        int dv[] = new int[256 * divsum];
        for (i = 0; i < 256 * divsum; i++) {
            dv[i] = (i / divsum);
        }

        yw = yi = 0;

        int[][] stack = new int[div][3];
        int stackpointer;
        int stackstart;
        int[] sir;
        int rbs;
        int r1 = radius + 1;
        int routsum, goutsum, boutsum;
        int rinsum, ginsum, binsum;

        for (y = 0; y < height; y++) {
            rinsum = ginsum = binsum = routsum = goutsum = boutsum = redSum = greenSum = blueSum = 0;
            for (i = -radius; i <= radius; i++) {
                p = pixels[yi + Math.min(wm, Math.max(i, 0))];
                sir = stack[i + radius];
                sir[0] = (p & 0xff0000) >> 16;
                sir[1] = (p & 0x00ff00) >> 8;
                sir[2] = (p & 0x0000ff);
                rbs = r1 - Math.abs(i);
                redSum += sir[0] * rbs;
                greenSum += sir[1] * rbs;
                blueSum += sir[2] * rbs;
                if (i > 0) {
                    rinsum += sir[0];
                    ginsum += sir[1];
                    binsum += sir[2];
                } else {
                    routsum += sir[0];
                    goutsum += sir[1];
                    boutsum += sir[2];
                }
            }
            stackpointer = radius;

            for (x = 0; x < width; x++) {

                redColor[yi] = dv[redSum];
                greenColor[yi] = dv[greenSum];
                blueColor[yi] = dv[blueSum];

                redSum -= routsum;
                greenSum -= goutsum;
                blueSum -= boutsum;

                stackstart = stackpointer - radius + div;
                sir = stack[stackstart % div];

                routsum -= sir[0];
                goutsum -= sir[1];
                boutsum -= sir[2];

                if (y == 0) {
                    vmin[x] = Math.min(x + radius + 1, wm);
                }
                p = pixels[yw + vmin[x]];

                sir[0] = (p & 0xff0000) >> 16;
                sir[1] = (p & 0x00ff00) >> 8;
                sir[2] = (p & 0x0000ff);

                rinsum += sir[0];
                ginsum += sir[1];
                binsum += sir[2];

                redSum += rinsum;
                greenSum += ginsum;
                blueSum += binsum;

                stackpointer = (stackpointer + 1) % div;
                sir = stack[(stackpointer) % div];

                routsum += sir[0];
                goutsum += sir[1];
                boutsum += sir[2];

                rinsum -= sir[0];
                ginsum -= sir[1];
                binsum -= sir[2];

                yi++;
            }
            yw += width;
        }
        for (x = 0; x < width; x++) {
            rinsum = ginsum = binsum = routsum = goutsum = boutsum = redSum = greenSum = blueSum = 0;
            yp = -radius * width;
            for (i = -radius; i <= radius; i++) {
                yi = Math.max(0, yp) + x;

                sir = stack[i + radius];

                sir[0] = redColor[yi];
                sir[1] = greenColor[yi];
                sir[2] = blueColor[yi];

                rbs = r1 - Math.abs(i);

                redSum += redColor[yi] * rbs;
                greenSum += greenColor[yi] * rbs;
                blueSum += blueColor[yi] * rbs;

                if (i > 0) {
                    rinsum += sir[0];
                    ginsum += sir[1];
                    binsum += sir[2];
                } else {
                    routsum += sir[0];
                    goutsum += sir[1];
                    boutsum += sir[2];
                }

                if (i < hm) {
                    yp += width;
                }
            }
            yi = x;
            stackpointer = radius;
            for (y = 0; y < height; y++) {
                // Preserve alpha channel: ( 0xff000000 & pixels[yi] )
                pixels[yi] = ( 0xff000000 & pixels[yi] ) | ( dv[redSum] << 16 ) | ( dv[greenSum] << 8 ) | dv[blueSum];

                redSum -= routsum;
                greenSum -= goutsum;
                blueSum -= boutsum;

                stackstart = stackpointer - radius + div;
                sir = stack[stackstart % div];

                routsum -= sir[0];
                goutsum -= sir[1];
                boutsum -= sir[2];

                if (x == 0) {
                    vmin[y] = Math.min(y + r1, hm) * width;
                }
                p = x + vmin[y];

                sir[0] = redColor[p];
                sir[1] = greenColor[p];
                sir[2] = blueColor[p];

                rinsum += sir[0];
                ginsum += sir[1];
                binsum += sir[2];

                redSum += rinsum;
                greenSum += ginsum;
                blueSum += binsum;

                stackpointer = (stackpointer + 1) % div;
                sir = stack[stackpointer];

                routsum += sir[0];
                goutsum += sir[1];
                boutsum += sir[2];

                rinsum -= sir[0];
                ginsum -= sir[1];
                binsum -= sir[2];

                yi += width;
            }
        }

        Log.e("pixels", width + " " + height + " " + pixels.length);
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height);

        return (bitmap);
    }
}
