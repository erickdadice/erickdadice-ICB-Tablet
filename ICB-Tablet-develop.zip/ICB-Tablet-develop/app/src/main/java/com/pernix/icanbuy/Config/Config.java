package com.pernix.icanbuy.Config;

public class Config {

    public static final String PAYPAL_CLIENT_ID="AUkSmp-jsAqzzdkGchQhUbFEbh_SIP8b08O3an8S9rYd7OIrPpp935D1TgSE-wwaxsxy1u4bcSF_i3Od";
}
