package com.pernix.icanbuy.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.pernix.icanbuy.R;

public class CualMetodoActivity extends AppCompatActivity {

    private AdView mAdView;
    Button pagar_tarjeta, pagar_Efectivo;
    TextView backtoCartText;
    ImageView backtoCartArrow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cual_metodo);

        pagar_tarjeta = (Button) findViewById(R.id.btnPagarTarjeta);
        pagar_tarjeta.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent in = new Intent(CualMetodoActivity.this, TotalAPagarActivity.class);
                startActivity(in);
            }
        });

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        pagar_Efectivo=(Button) findViewById(R.id.btnPagarEfectivo);
        pagar_Efectivo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(CualMetodoActivity.this, EfectivoActivity.class);
                startActivity(in);
            }
        });

        backtoCartText=(TextView)findViewById(R.id.backToCartText);
        backtoCartArrow=(ImageView)findViewById(R.id.backToCartArrow);

        backtoCartText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), CartActivity.class);
                startActivity(intent);
            }
        });
        backtoCartArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), CartActivity.class);
                startActivity(intent);
            }
        });
    }



}