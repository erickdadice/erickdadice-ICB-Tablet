package com.pernix.icanbuy.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.pernix.icanbuy.R;
import com.pernix.icanbuy.models.Factura.FacturaRecord;
import com.pernix.icanbuy.utils.PropertiesConfig;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;

public class TotalAPagarActivity extends AppCompatActivity {
private TextView txtSinImpuestos, txtImpuestos, txtTotalFinal;
private String sinImpuestos;
Button btnInicio;
private double calcFinal;
    private PropertiesConfig propertiesConfig;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_total_a_pagar);

        txtSinImpuestos=(TextView)findViewById(R.id.txtTotalSinImpuestos);
        txtImpuestos=(TextView)findViewById(R.id.txtImpuestos);
        txtTotalFinal=(TextView)findViewById(R.id.txtTotalFinal);
        btnInicio=(Button)findViewById(R.id.btnInicio);


        sinImpuestos=CartActivity.totalCarrito;
        double calcImpuesto = Double.parseDouble(sinImpuestos)*0.13;
       calcFinal = calcImpuesto+Double.parseDouble(sinImpuestos);

        txtSinImpuestos.setText("Monto inicial: "+CartActivity.totalCarrito);
        txtImpuestos.setText("IVA (13%): + "+calcImpuesto);
        txtTotalFinal.setText("Total a pagar: "+calcFinal);

        new PatchTotal().execute();

        btnInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }//on create



    public class PatchTotal extends AsyncTask<Void,Void, FacturaRecord> {

        @Override
        protected FacturaRecord doInBackground(Void... voids) {
            try{
                URL url = new URL("https://api.airtable.com/v0/appPvM705sztvANQP/ConexionCarrito?filterByFormula=IDTablet=1");
                HttpURLConnection http = (HttpURLConnection)url.openConnection();
                http.setRequestMethod("PATCH");
                http.setDoOutput(true);
                http.setRequestProperty("Authorization", "Bearer "+propertiesConfig.getAirtableApiKey());
                http.setRequestProperty("Content-Type", "application/json");

                JSONObject jsonObjectFields = new JSONObject();
                try{
                    jsonObjectFields.put("fields",datosCC());
                }catch (Exception exception){
                    exception.printStackTrace();
                }

                byte[] out = jsonObjectFields.toString().getBytes(StandardCharsets.UTF_8);

                OutputStream stream = http.getOutputStream();
                stream.write(out);

                System.out.println(http.getResponseCode() + " " + http.getResponseMessage());
                http.disconnect();
            }catch(Exception e){
                e.printStackTrace();
            }
            return null;
        }//do in background
    }//async post Factura


    private JSONObject datosCC() throws JSONException {
        JSONObject params = new JSONObject();
        params.put( "totalAPagar", calcFinal);

        return params;
    }
}//activity
