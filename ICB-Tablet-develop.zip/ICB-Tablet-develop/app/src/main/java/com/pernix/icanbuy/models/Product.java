package com.pernix.icanbuy.models;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

import java.io.Serializable;

@Root
public class Product implements Serializable {
    @Element
    private Long idProducto;

    @Element
    private String descripcion;
    @Element
    private String marca;
    @Element
    private int cantidadDisponible;
    @Element
    private String categoria;
    @Element
    private double precio;
    @Element
    private String gravado;
    @Element
    private String barcode;
    @Element
    private int idSupermercado;

    public Product(Long idProducto, String descripcion, String marca,
                   int cantidadDisponible, String categoria, double precio,
                   String gravado, String barcode, int idSupermercado) {
        this.idProducto = idProducto;
        this.descripcion = descripcion;
        this.marca = marca;
        this.cantidadDisponible = cantidadDisponible;
        this.categoria = categoria;
        this.precio = precio;
        this.gravado = gravado;
        this.barcode = barcode;
        this.idSupermercado = idSupermercado;
    }

    public Product() {
    }

    public Long getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(Long idProducto) {
        this.idProducto = idProducto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getCantidadDisponible() {
        return cantidadDisponible;
    }

    public void setCantidadDisponible(int cantidadDisponible) {
        this.cantidadDisponible = cantidadDisponible;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getGravado() {
        return gravado;
    }

    public void setGravado(String gravado) {
        this.gravado = gravado;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public int getIdSupermercado() {
        return idSupermercado;
    }

    public void setIdSupermercado(int idSupermercado) {
        this.idSupermercado = idSupermercado;
    }
}
