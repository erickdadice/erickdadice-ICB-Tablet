/**
 * Credits for the bluetooth connection: Created by sash0k
 */

package com.pernix.icanbuy.bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.os.Message;

import com.pernix.icanbuy.bluetooth.bluetoothThread.ConnectThread;
import com.pernix.icanbuy.bluetooth.bluetoothThread.ConnectedThread;
import static com.pernix.icanbuy.constants.BluetoothConstant.*;
import static com.pernix.icanbuy.constants.BluetoothState.*;

public class BluetoothDeviceConnector {
    private int state;

    private final BluetoothAdapter bluetoothAdapter;
    private final BluetoothDevice connectedDevice;
    private ConnectThread connectThread;
    private ConnectedThread connectedThread;
    private final Handler finalHandler;
    private final String deviceName;


    public BluetoothDeviceConnector(BluetoothDeviceInfo deviceData, Handler handler) {
        finalHandler = handler;
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        connectedDevice = bluetoothAdapter.getRemoteDevice(deviceData.getAddress());
        deviceName = (deviceData.getName() == null) ? deviceData.getAddress() : deviceData.getName();
        state = STATE_NONE;
    }

    /**
     * The connection request from the Device Features
     */
    public synchronized void connect() {
        if (state == STATE_CONNECTING && connectThread != null){
            connectThread = null;
        }

        if (connectedThread != null) {
            connectedThread.cancel();
            connectedThread = null;
        }

        // Start the thread to connect with the given device
        connectThread = new ConnectThread(connectedDevice, bluetoothAdapter, this, finalHandler,
                                            connectThread);
        connectThread.start();
        setState(STATE_CONNECTING);
    }

    /**
     * Disconnecting
     */
    public synchronized void stop() {
        if (connectThread != null) {
            connectThread = null;
        }
        if (connectedThread != null) {
            connectedThread.cancel();
            connectedThread = null;
        }
        setState(STATE_NONE);
    }

    /**
     * Installing an internal device status
     *
     */
    public synchronized void setState(int state) {
        this.state = state;
        finalHandler.obtainMessage(MESSAGE_STATE_CHANGE, state, -1).sendToTarget();
    }


    /**
     * Getting the status of the device
     */
    public synchronized int getState() {
        return state;
    }

    public synchronized void connected(BluetoothSocket socket) {
        // Cancel the thread that completed the connection
        if (connectThread != null) {
            connectThread = null;
        }

        if (connectedThread != null) {
            connectedThread.cancel();
            connectedThread = null;
        }

        setState(STATE_CONNECTED);

        // Send the name of the connected device back to the UI Activity
        Message msg = finalHandler.obtainMessage(MESSAGE_DEVICE_NAME, deviceName);
        finalHandler.sendMessage(msg);

        // Start the thread to manage the connection and perform transmissions
        connectedThread = new ConnectedThread(socket, finalHandler, this);
        connectedThread.start();
    }

}
