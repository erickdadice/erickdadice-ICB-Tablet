package com.pernix.icanbuy.models.Factura;

import org.simpleframework.xml.Element;

import java.io.Serializable;
import java.util.Date;

public class Factura implements Serializable {
    @Element
    private int IdFactura;

    @Element
    private int IdUsuario;

    @Element
    private Date FechaCompra;

    @Element
    private Double Total;


    public Factura(int idFactura, int idUsuario, Date fechaCompra, Double total) {
        IdFactura = idFactura;
        IdUsuario = idUsuario;
        FechaCompra = fechaCompra;
        Total = total;
    }

    public Factura() {
    }

    public int getIdFactura() {
        return IdFactura;
    }

    public void setIdFactura(int idFactura) {
        this.IdFactura = idFactura;
    }

    public int getIdUsuario() {
        return IdUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.IdUsuario = idUsuario;
    }

    public Date getFechaCompra() {
        return FechaCompra;
    }

    public void setFechaCompra(Date fechaCompra) {
        this.FechaCompra = fechaCompra;
    }

    public Double getTotal() {
        return Total;
    }

    public void setTotal(Double total) {
        this.Total = total;
    }
}
