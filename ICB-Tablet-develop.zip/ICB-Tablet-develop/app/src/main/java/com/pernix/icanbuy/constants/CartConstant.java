package com.pernix.icanbuy.constants;

public class CartConstant {

    public static final String PRODUCT_NOT_FIND_MESSAGE = "No se encontró el producto";
}
