package com.pernix.icanbuy.services;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.style.RelativeSizeSpan;
import android.util.Log;

import com.pernix.icanbuy.activities.CartActivity;
import com.pernix.icanbuy.bluetooth.BluetoothDeviceConnector;
import com.pernix.icanbuy.bluetooth.BluetoothDeviceInfo;
import com.pernix.icanbuy.bluetooth.BluetoothResponseHandler;
import com.pernix.icanbuy.constants.BluetoothState;
import com.pernix.icanbuy.presenters.CartPresenter;
import com.pernix.icanbuy.utils.BluetoothUtil;
import com.pernix.icanbuy.utils.PropertiesConfig;

import static com.pernix.icanbuy.constants.BluetoothConstant.APPLICATION_NAME;
import static com.pernix.icanbuy.constants.BluetoothConstant.BLUETOOTH_IS_CONNECTED_TO_MESSAGE;
import static com.pernix.icanbuy.constants.BluetoothConstant.BLUETOOTH_SETUP_MESSAGE;
import static com.pernix.icanbuy.constants.BluetoothConstant.DEVICE_NAME;
import static com.pernix.icanbuy.constants.BluetoothConstant.MSG_NOT_CONNECTED;
import static com.pernix.icanbuy.constants.BluetoothConstant.NEW_DEVICE;
import static com.pernix.icanbuy.constants.BluetoothConstant.SAVED_PENDING_REQUEST_ENABLE_BT;
import static com.pernix.icanbuy.constants.BluetoothConstant.SETUP_CONNECTOR_FAILED;


public class BluetoothService {
    private String deviceName;
    private static BluetoothDeviceConnector connector;
    private BluetoothAdapter btAdapter;
    boolean pendingRequestEnableBt = false;
    private static BluetoothResponseHandler mHandler;
    private CartPresenter presenter;
    private Context context;

    public BluetoothService(CartPresenter cartPresenter, Bundle savedInstanceState, CartActivity context) {
        this.context = context;
        initializeBluetoothConnection(savedInstanceState, context);
        this.presenter = cartPresenter;
    }

    public void finalize() {
        if (connector != null){
            connector.stop();
            connector = null;
        }
        mHandler = null;
    }

    public void initializeAdapter(PropertiesConfig propertiesConfig) {
        //Verify adapter status
       /* if (!btAdapter.isEnabled()) {
            btAdapter.enable();
            try {
                Thread.sleep(2500);
            } catch (InterruptedException e) {
            }
        } else {
            Log.i(APPLICATION_NAME, BLUETOOTH_ON_MESSAGE);
        }*/

        //TODO: ARCHIVE MACADDRESS
        BluetoothDevice device = btAdapter.getRemoteDevice(propertiesConfig.getMacAddress());

        if (isAdapterReady() && (connector == null)) {
            setupConnector(device);
        }
        if (connector == null) {
            setupConnector(device);
        }
    }

    private boolean isConnected() {
        Log.i(APPLICATION_NAME, BLUETOOTH_IS_CONNECTED_TO_MESSAGE);
        return (connector != null) && (connector.getState() == BluetoothState.STATE_CONNECTED);
    }

    private void setupConnector(BluetoothDevice connectedDevice) {
        Log.i(APPLICATION_NAME, BLUETOOTH_SETUP_MESSAGE);
        try {
            BluetoothDeviceInfo data = new BluetoothDeviceInfo(connectedDevice, NEW_DEVICE);
            connector = new BluetoothDeviceConnector(data, mHandler);
            connector.connect();
        } catch (IllegalArgumentException e) {
            BluetoothUtil.log(SETUP_CONNECTOR_FAILED + e.getMessage());
        }
    }

    boolean isAdapterReady() {
        return (btAdapter != null) && (btAdapter.isEnabled());
    }

    public void showNotConnectedToast() {

        SpannableStringBuilder messageNotConnectedSpannableString = new SpannableStringBuilder(MSG_NOT_CONNECTED);
        messageNotConnectedSpannableString.setSpan(new RelativeSizeSpan(1.35f), 0, MSG_NOT_CONNECTED.length(), 0);

    }

    public void appendLog(String message) {
        System.out.println("BEFORE " + message);
        message = formatMessage(message);
        presenter.addCartItem(message);
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String formatMessage(String message) {
        return message.replaceAll("(\\r|\\n|\\t)", "");
    }

    public void initializeBluetoothConnection(Bundle savedInstanceState, CartActivity activity) {
        //Initialize the bluetooth adapter
        btAdapter = BluetoothAdapter.getDefaultAdapter();

        //Set activity handler class
        if (mHandler == null) mHandler = new BluetoothResponseHandler(activity, this);
        else mHandler.setTarget(activity);

        //Verify bluetooth status
        if (isConnected() && (savedInstanceState != null)) {
            setDeviceName(savedInstanceState.getString(DEVICE_NAME));
        } else {
            Log.i(APPLICATION_NAME, MSG_NOT_CONNECTED);
        }
    }

    public void setBluetoothState(Bundle outState) {
        outState.putBoolean(SAVED_PENDING_REQUEST_ENABLE_BT, pendingRequestEnableBt);
        outState.putString(DEVICE_NAME, deviceName);
    }
}
