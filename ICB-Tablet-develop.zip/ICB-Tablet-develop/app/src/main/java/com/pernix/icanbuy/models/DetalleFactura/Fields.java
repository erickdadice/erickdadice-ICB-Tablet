package com.pernix.icanbuy.models.DetalleFactura;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Fields {
    private int IdDetalle;
    private int IdFactura;
    private String IdProducto;
    private Double CantidadComprada;
    private Double Precio;
    private String Gravado;
    private Double Subtotal;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public int getIdDetalle() {
        return IdDetalle;
    }

    public void setIdDetalle(int idDetalle) {
        IdDetalle = idDetalle;
    }

    public int getIdFactura() {
        return IdFactura;
    }

    public void setIdFactura(int idFactura) {
        IdFactura = idFactura;
    }

    public String getIdProducto() {
        return IdProducto;
    }

    public void setIdProducto(String idProducto) {
        IdProducto = idProducto;
    }

    public Double getCantidadComprada() {
        return CantidadComprada;
    }

    public void setCantidadComprada(Double cantidadComprada) {
        CantidadComprada = cantidadComprada;
    }

    public Double getPrecio() {
        return Precio;
    }

    public void setPrecio(Double precio) {
        Precio = precio;
    }

    public String getGravado() {
        return Gravado;
    }

    public void setGravado(String gravado) {
        Gravado = gravado;
    }

    public Double getSubtotal() {
        return Subtotal;
    }

    public void setSubtotal(Double subtotal) {
        Subtotal = subtotal;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
