package com.pernix.icanbuy.adapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.pernix.icanbuy.R;

public class ImageListAdapter extends BaseAdapter{
    Context context;
    int[] imageNames;
    LayoutInflater inflter;

    public ImageListAdapter(Context applicationContext, int[] imageNames) {
        this.context = applicationContext;
        this.imageNames = imageNames;
        inflter = (LayoutInflater.from(applicationContext));

    }

    @Override
    public int getCount() {
        return imageNames.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        view = inflter.inflate(R.layout.image_information_panel, null);
        ImageView informationImage = (ImageView) view.findViewById(R.id.informationImage);
        informationImage.setImageResource(imageNames[position]);
        return view;
    }
}
