package com.pernix.icanbuy.models;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

import java.io.Serializable;

@Root
public class BillingRequest implements Serializable {

    @Element
    private Cart cart;
    @Element
    private String email;

    public BillingRequest(){

    }

    public BillingRequest(Cart cart, String email){
        this.cart = cart;
        this.email = email;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
