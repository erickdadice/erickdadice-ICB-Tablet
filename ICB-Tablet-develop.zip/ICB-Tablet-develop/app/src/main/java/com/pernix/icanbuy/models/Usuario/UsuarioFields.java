package com.pernix.icanbuy.models.Usuario;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UsuarioFields {
    private long idUsuario;
    private String nombre;
    private String apellido;
    private Date fechaNac;
    private String correo;
    private String contrasena;
    private List<String> usuarioRol;

    public List<String> getUsuarioRol() {
        return usuarioRol;
    }

    public void setUsuarioRol(List<String> usuarioRol) {
        this.usuarioRol = usuarioRol;
    }

    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public Date getFechaNac() {
        return fechaNac;
    }

    public void setFechaNac(Date fechaNac) {
        this.fechaNac = fechaNac;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public void setAdditionalProperties(Map<String, Object> additionalProperties) {
        this.additionalProperties = additionalProperties;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
