package com.pernix.icanbuy.adapter;

import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.view.View;
import android.widget.TextView;

import com.pernix.icanbuy.R;
import com.pernix.icanbuy.models.CartItem;

public class ProductRowView {

    private TextView textViewCode = null;
    private TextView textViewQuantity = null;
    private TextView textViewArticle = null;
    private TextView textViewUnitPrice = null;
    private TextView textViewTotal = null;

    public void initializeTextViews(View convertView) {

        textViewCode = (TextView) convertView.findViewById(R.id.textview_code);
        textViewQuantity = (TextView) convertView.findViewById(R.id.textview_quantity);
        textViewArticle = (TextView) convertView.findViewById(R.id.textview_article);
        textViewUnitPrice = (TextView) convertView.findViewById(R.id.textview_unit_price);
        textViewTotal = (TextView) convertView.findViewById(R.id.textview_total);
    }

    public void setTextViewContent(CartItem item) {
        String articleNameDescription = item.getProduct().getMarca() +
                "\n" + item.getProduct().getDescripcion();//getName y Description
        int articleNameLength = item.getProduct().getMarca().length();
//int articleNameLength = item.getProduct().getName.length();
        textViewCode.setText(String.valueOf(item.getProduct().getIdProducto()));//getCode
        //textViewCode.setText(item.getProduct().getCode());
        textViewQuantity.setText(String.valueOf(item.getQuantity()));
        textViewTotal.setText(String.valueOf(item.getTotal()));

        SpannableString articleSpannableString = new SpannableString(articleNameDescription);
        articleSpannableString.setSpan(new RelativeSizeSpan(0.8f),
                articleNameLength, articleSpannableString.length(), 0);

        textViewArticle.setText(articleSpannableString);
        textViewUnitPrice.setText(String.valueOf(item.getProduct().getPrecio()));//getPrice
    }
}
