package com.pernix.icanbuy.models.Supermercado;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

import java.io.Serializable;

@Root
public class Supermercado implements Serializable{
    @Element
    private int idSupermercado;

    @Element
    private String nombre;

    @Element
    private String direccion;

    public Supermercado(int idSupermercado, String nombre, String direccion) {
        this.idSupermercado = idSupermercado;
        this.nombre = nombre;
        this.direccion = direccion;
    }

    public Supermercado() {
    }

    public int getIdSupermercado() {
        return idSupermercado;
    }

    public void setIdSupermercado(int idSupermercado) {
        this.idSupermercado = idSupermercado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}
