package com.pernix.icanbuy.constants;

public class BluetoothConstant {

    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_DEVICE_NAME = 4;
    public static final int MESSAGE_TOAST = 5;
    public static final String MSG_NOT_CONNECTED= "Dispositivo no conectado, por favor comuníquese con un asesor";
    public static final String MSG_CONNECTING= "Connecting…";
    public static final String MSG_CONNECTED= "Connected";
    public static final String SAVED_PENDING_REQUEST_ENABLE_BT = "PENDING_REQUEST_ENABLE_BT";
    public static final String DEVICE_NAME = "DEVICE_NAME";
    public static final String APPLICATION_NAME = "ICanBuy";
    public static final String BLUETOOTH_ON_MESSAGE = "Bluetooth already on";
    public static final String BLUETOOTH_HANDLE_MESSAGE = "Handle message device control activity";
    public static final String BLUETOOTH_IS_CONNECTED_TO_MESSAGE= "Is connected control activity";
    public static final String BLUETOOTH_SETUP_MESSAGE = "Set up connector control activity";
    public static final String SETUP_CONNECTOR_FAILED = "setupConnector failed: ";
    public static final String CONNECTION_FAILED= "Connection failed device connector";
    public static final String NEW_DEVICE= "<New device>";

}
