package com.pernix.icanbuy.activities;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pernix.icanbuy.R;
import com.pernix.icanbuy.models.ConexionCarrito.ConexionCarrito;
import com.pernix.icanbuy.models.ConexionCarrito.ConexionCarritoRecord;
import com.pernix.icanbuy.models.ConexionCarrito.ConexionCarritoRecords;
import com.pernix.icanbuy.utils.PropertiesConfig;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class QrActivity extends AppCompatActivity implements AsyncTaskCallback{
    String Respuesta;
    StringBuffer Respuesta_Web;
    URL url;
    Handler h2 = new Handler();
    private ProgressDialog dialog;
    ArrayList<ConexionCarrito> cons = new ArrayList<ConexionCarrito>();
    Activity activity;
    String mCarrito=null;
    private PropertiesConfig propertiesConfig;
    QrActivity context = this;

    @Override
    public void onPostExecute(Object result) {
        switchToCartActivity();
    }
/*
    Runnable run = new Runnable() {
        @Override
        public void run() {
            //Verificar en la tabla del maestro de carrito si ya un registro con el Id de la tablet en estado "INICIADO"
            //MaestroCarrito mCarrito = new LlamadaAPI(CONSTANTES.MYIDDETABLET);
            try {
                ObtenerDatos obtenerDatos = new ObtenerDatos("1", context);
                        obtenerDatos.execute();
            } catch (Exception e) {
                e.printStackTrace();
            }



        }
    };*/


/*
    @Override
    public void onPostExecute(Object result) {
        if (mCarrito == null) {
            h2.postDelayed(getApplicationContext(), 1000);
        } else {
            //revisar tablet ID (debe ser constante) y el estado iniciado del usuario
            switchToCartActivity();
        }
    }*/
//llamada al API

    public class ObtenerDatos extends AsyncTask<Void, Void, ConexionCarritoRecord> {

        private String idtablet="1";
        public AsyncTaskCallback callback = null;

        public ObtenerDatos(String idtablet, AsyncTaskCallback callback){
            this.callback = callback;
        }


        @Override
        protected ConexionCarritoRecord doInBackground(Void... voids) {
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(JsonParser.Feature.IGNORE_UNDEFINED, true);
            mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
            mapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
            mapper.configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true);
            MappingJackson2HttpMessageConverter messageConverter = new MappingJackson2HttpMessageConverter();
            messageConverter.setObjectMapper(mapper);
            List<HttpMessageConverter<?>> converters = new ArrayList<HttpMessageConverter<?>>();
            converters.add(messageConverter);
            HttpHeaders requestHeaders = new HttpHeaders();
            requestHeaders.set("Authorization", "Bearer " + Constants.AIRTABLE_API_KEY);
            RestTemplate restTemplate = new RestTemplate(true);
            for (int i = 0; i < restTemplate.getMessageConverters().size(); i++) {
                if (!restTemplate.getMessageConverters().get(i).getClass().getName().equals(MappingJackson2HttpMessageConverter.class.getName())) {
                    converters.add(restTemplate.getMessageConverters().get(i));
                }
            }
            restTemplate.setMessageConverters(converters);
            restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory());
            HttpEntity<?> httpEntity = new HttpEntity<Object>("", requestHeaders);

            String url = Constants.AIRTABLE_BASE_URL +
                    "ConexionCarrito?filterByFormula=IDTablet=1";

            Log.d("http", url);
            ResponseEntity<ConexionCarritoRecords> response = restTemplate.exchange(url, HttpMethod.GET, httpEntity, ConexionCarritoRecords.class);
            Log.d("http", response.getStatusCode().toString());

            if (response.getStatusCode() == HttpStatus.OK) {
                if (response.getBody().getRecords().size() > 0) {
                    mCarrito="1";
                   // switchToCartActivity();

                    return response.getBody().getRecords().get(0);

                }
            }
            return null;
        }
        @Override
        protected void onPostExecute(ConexionCarritoRecord result) {
            if(callback != null) {
                callback.onPostExecute(result);
            }
            super.onPostExecute(result);
        }



    }



    //AppCompat
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr);
        Button qrButton = (Button) findViewById(R.id.qrButton);
        //h2.postDelayed(run, 1000);
        qrButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                switchToCartActivity();

            }
        });

        ObtenerDatos obtenerDatos = new ObtenerDatos("1", context);
        obtenerDatos.execute();


    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void switchToCartActivity(){
        Intent intent= new Intent(this, CartActivity.class);
      //  intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
       // intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
      //  intent.addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
       // intent.putExtra("ID_maestro_carrito",id);
        startActivity(intent);
    }
}