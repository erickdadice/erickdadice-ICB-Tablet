package com.pernix.icanbuy.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.pernix.icanbuy.R;
import com.pernix.icanbuy.presenters.CartObserver;
import com.pernix.icanbuy.presenters.CartPresenter;
import com.pernix.icanbuy.services.DALService;

public class EfectivoActivity extends AppCompatActivity  {

    Button btnRegresarInicio;
    TextView backtoCartText, total_a_pagar;
    ImageView backtoCartArrow;
    private CartPresenter presenter;

    public CartPresenter getPresenter() {
        return this.presenter;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_efectivo);

        DALService firebaseService = new DALService(this);
        presenter = new CartPresenter(firebaseService, this);
        total_a_pagar = (TextView)findViewById(R.id.total_a_pagar);


        btnRegresarInicio=(Button)findViewById(R.id.regresar_inicio);
        btnRegresarInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        backtoCartText=(TextView)findViewById(R.id.backToCartText);
        backtoCartArrow=(ImageView)findViewById(R.id.backToCartArrow);

        backtoCartText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), CualMetodoActivity.class);
                startActivity(intent);
            }
        });
        backtoCartArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), CualMetodoActivity.class);
                startActivity(intent);
            }
        });

        total_a_pagar.setText("Total a pagar: "+CartActivity.totalCarrito);

    }

}