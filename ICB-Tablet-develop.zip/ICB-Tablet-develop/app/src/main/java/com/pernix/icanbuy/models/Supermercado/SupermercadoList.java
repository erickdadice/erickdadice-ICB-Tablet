package com.pernix.icanbuy.models.Supermercado;

import java.util.HashMap;

public class SupermercadoList {
    private HashMap<String, Supermercado> supermercadoList;

    public SupermercadoList(){
        supermercadoList = new HashMap<String, Supermercado>();
    }

    public SupermercadoList(HashMap<String, Supermercado> supermercadoList) { this.supermercadoList = supermercadoList; }

    public void setSupermercadoList(HashMap<String, Supermercado> supermercadoList) { this.supermercadoList = supermercadoList; }

    public HashMap<String, Supermercado> getSupermercadoList() { return supermercadoList; }

    public void addSupermercado(Supermercado supermercado){
        supermercadoList.put(String.valueOf(supermercado.getIdSupermercado()), supermercado);
    }

    public Supermercado getSupermercado(String id){
        return supermercadoList.get(id);
    }



}
