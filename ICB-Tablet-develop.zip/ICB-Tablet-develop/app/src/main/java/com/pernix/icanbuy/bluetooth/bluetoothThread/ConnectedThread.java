package com.pernix.icanbuy.bluetooth.bluetoothThread;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.pernix.icanbuy.bluetooth.BluetoothDeviceConnector;

import java.io.IOException;
import java.io.InputStream;
import static com.pernix.icanbuy.constants.BluetoothConstant.MESSAGE_READ;
import static com.pernix.icanbuy.constants.BluetoothConstant.MESSAGE_TOAST;
import static com.pernix.icanbuy.constants.BluetoothState.STATE_NONE;

/**
 * Created by Roberto on 10/13/2015.
 */
public class ConnectedThread extends Thread {


    private final BluetoothDeviceConnector bluetoothDeviceConnector;
    private Handler finalHandler;
    private final BluetoothSocket mmSocket;
    private final InputStream mmInStream;

    public ConnectedThread(BluetoothSocket socket, Handler finalHandler, BluetoothDeviceConnector bluetoothDeviceConnector) {
        mmSocket = socket;
        InputStream tmpIn = null;
        this.finalHandler = finalHandler;
        this.bluetoothDeviceConnector = bluetoothDeviceConnector;

        // Get the BluetoothSocket input and output streams
        try {
            tmpIn = socket.getInputStream();
        } catch (IOException e) {

        }
        mmInStream = tmpIn;
    }
    /**
     * The basic working method - waits for commands from the incoming stream
     */
    public void run() {
        byte[] buffer = new byte[512];
        int bytes;
        StringBuilder readMessage = new StringBuilder();
        while (true) {
            try {
                bytes = mmInStream.read(buffer);
                String read = new String(buffer, 0, bytes);
                readMessage.append(read);

                if (read.contains("\n")) {
                    finalHandler.obtainMessage(MESSAGE_READ, bytes, -1, readMessage.toString()).sendToTarget();
                    readMessage.setLength(0);
                }

            } catch (IOException e) {
                connectionLost();
                break;
            }
        }
    }
    /**
     * Write a piece of data to the device

     public void writeData(byte[] chunk) {
     try {
     mmOutStream.write(chunk);
     mmOutStream.flush();
     // Share the sent message back to the UI Activity
     finalHandler.obtainMessage(MESSAGE_WRITE, -1, -1, chunk).sendToTarget();
     } catch (IOException e) {
     if (D) Log.e(TAG, "Exception during write", e);
     }
     }*/


    /**
     * Write bytes
     *
     public void write(byte command) {
     byte[] buffer = new byte[1];
     buffer[0] = command;

     try {
     mmOutStream.write(buffer);

     // Share the sent message back to the UI Activity
     finalHandler.obtainMessage(MESSAGE_WRITE, -1, -1, buffer).sendToTarget();
     } catch (IOException e) {
     return;
     }
     }*/

    /**
     * Cancel - closes the socket
     */

    /**
     * Send a failure message back to the Activity
     */
    private void connectionLost() {
        Message msg = finalHandler.obtainMessage(MESSAGE_TOAST);
        Bundle bundle = new Bundle();
        msg.setData(bundle);
        finalHandler.sendMessage(msg);
        bluetoothDeviceConnector.setState(STATE_NONE);
    }

    public void cancel() {
        try {
            mmSocket.close();
        } catch (IOException e) {
            return;
        }
    }
}
