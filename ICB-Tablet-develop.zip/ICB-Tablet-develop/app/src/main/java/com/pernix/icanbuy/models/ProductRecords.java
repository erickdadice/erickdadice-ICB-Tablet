package com.pernix.icanbuy.models;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Ricardo on 2020-12-06.
 */

public class ProductRecords {

    private List<Record> records = null;
    private String offset;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public List<Record> getRecords() {
        return records;
    }

    public void setRecords(List<Record> records) {
        this.records = records;
    }

    public String getOffset() {
        return offset;
    }

    public void setOffset(String offset) {
        this.offset = offset;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
