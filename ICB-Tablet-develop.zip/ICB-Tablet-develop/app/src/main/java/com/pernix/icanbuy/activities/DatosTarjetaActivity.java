package com.pernix.icanbuy.activities;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.braintreepayments.cardform.view.CardForm;
import com.pernix.icanbuy.R;

public class DatosTarjetaActivity extends AppCompatActivity {
    CardForm cardForm;
    Button buy;
    AlertDialog.Builder alertBuilder;
    TextView txtRegresar;
    ImageView backtoCartArrow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datos_tarjeta);

        txtRegresar=findViewById(R.id.backToCartText);
        txtRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), CualMetodoActivity.class);
                startActivity(intent);
            }
        });
        backtoCartArrow=(ImageView)findViewById(R.id.backToCartArrow);
        backtoCartArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), CualMetodoActivity.class);
                startActivity(intent);
            }
        });

        Bundle bundle = getIntent().getExtras();
        if (bundle !=null){
            if(bundle.getString("some") != null);
            Toast.makeText(getApplicationContext(),
                    "data:" + bundle.getString("some"),
                    Toast.LENGTH_SHORT).show();

        }


        cardForm = findViewById(R.id.card_form);
        buy = findViewById(R.id.btnBuy);
        cardForm.cardRequired(true)
                .expirationRequired(true)
                .cvvRequired(true)
                .postalCodeRequired(true)
                .mobileNumberRequired(true)
                .mobileNumberExplanation("SMS es requerido")
                .setup(DatosTarjetaActivity.this);
        cardForm.getCvvEditText().setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cardForm.isValid()) {
                    alertBuilder = new AlertDialog.Builder(DatosTarjetaActivity.this);
                    alertBuilder.setTitle("Verifique sus datos");
                    alertBuilder.setMessage("Número: " + cardForm.getCardNumber() + "\n" +
                            "Fecha de vencimiento: " + cardForm.getExpirationDateEditText().getText().toString() + "\n" +
                            "CVV: " + cardForm.getCvv() + "\n" +
                            "Código postal: " + cardForm.getPostalCode() + "\n" +
                            "Celular: " + cardForm.getMobileNumber()+"\n" +
                            "Total a pagar: "+CartActivity.totalCarrito);
                    alertBuilder.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                            Toast.makeText(DatosTarjetaActivity.this, "Su pago se ha realizado con éxito", Toast.LENGTH_LONG).show();
                            (new Handler()).postDelayed(this::switchActivity, 5000);
                        }

                        private void switchActivity() {
                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(intent);
                        }

                    });
                    alertBuilder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    });
                    AlertDialog alertDialog = alertBuilder.create();
                    alertDialog.show();

                } else {
                    Toast.makeText(DatosTarjetaActivity.this, "Por favor complete el formulario", Toast.LENGTH_LONG).show();
                }
            }
        });
    }


}