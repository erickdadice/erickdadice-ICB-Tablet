package com.pernix.icanbuy.bluetooth;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.pernix.icanbuy.activities.CartActivity;
import com.pernix.icanbuy.constants.BluetoothState;
import com.pernix.icanbuy.services.BluetoothService;
import com.pernix.icanbuy.utils.BluetoothUtil;

import java.lang.ref.WeakReference;

import static com.pernix.icanbuy.constants.BluetoothConstant.APPLICATION_NAME;
import static com.pernix.icanbuy.constants.BluetoothConstant.BLUETOOTH_HANDLE_MESSAGE;
import static com.pernix.icanbuy.constants.BluetoothConstant.MESSAGE_DEVICE_NAME;
import static com.pernix.icanbuy.constants.BluetoothConstant.MESSAGE_READ;
import static com.pernix.icanbuy.constants.BluetoothConstant.MESSAGE_STATE_CHANGE;
import static com.pernix.icanbuy.constants.BluetoothConstant.MSG_CONNECTED;
import static com.pernix.icanbuy.constants.BluetoothConstant.MSG_CONNECTING;
import static com.pernix.icanbuy.constants.BluetoothConstant.MSG_NOT_CONNECTED;


public class BluetoothResponseHandler extends Handler {
    private WeakReference<CartActivity> mActivity;
    private BluetoothService bluetoothService;

    public BluetoothResponseHandler(CartActivity activity, BluetoothService bluetoothService) {
        mActivity = new WeakReference<CartActivity>(activity);
        this.bluetoothService = bluetoothService;
    }

    public void setTarget(CartActivity target) {
        mActivity.clear();
        mActivity = new WeakReference<CartActivity>(target);
    }

    @Override
    public void handleMessage(Message msg) {
        Log.i(APPLICATION_NAME, BLUETOOTH_HANDLE_MESSAGE);
        CartActivity activity = mActivity.get();
        if (activity != null) {
            switch (msg.what) {
                case MESSAGE_STATE_CHANGE:
                    BluetoothUtil.log("MESSAGE_STATE_CHANGE: " + msg.arg1);
                    switch (msg.arg1) {
                        case BluetoothState.STATE_CONNECTED:
                            Log.d(APPLICATION_NAME, MSG_CONNECTED);
                            break;
                        case BluetoothState.STATE_CONNECTING:
                            Log.d(APPLICATION_NAME, MSG_CONNECTING);
                            break;
                        case BluetoothState.STATE_NONE:
                            Log.d(APPLICATION_NAME, MSG_NOT_CONNECTED);
                            if(mActivity.toString() != "CartActivity")
                            bluetoothService.showNotConnectedToast();
                            break;
                    }
                    break;

                case MESSAGE_READ:
                    final String readMessage = (String) msg.obj;
                    if (readMessage != null) {
                        bluetoothService.appendLog(readMessage);
                    }
                    break;

                case MESSAGE_DEVICE_NAME:
                    bluetoothService.setDeviceName((String) msg.obj);
                    break;
            }
        }
    }
}
