package com.pernix.icanbuy.activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.pernix.icanbuy.R;
import com.pernix.icanbuy.models.BillingRequest;
import com.pernix.icanbuy.models.Cart;
import com.pernix.icanbuy.services.XmlPostService;
import com.pernix.icanbuy.utils.BlurUtil;
import com.pernix.icanbuy.utils.ScreenshotUtil;
import com.pernix.icanbuy.utils.XmlUtil;

import java.io.IOException;

public class PaymentActivity extends Activity {

    public static final String CART_KEY = "cart";
    private String mailPerson;
    private BillingRequest billingRequest;
    private AlertDialog alert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_method);

        Intent intent = getIntent();
        final Cart cart = (Cart) intent.getSerializableExtra(CART_KEY);
        TextView totalPay = (TextView) findViewById(R.id.totalPaymentMethod);
        totalPay.setText(String.valueOf(cart.getCartTotal()));


        getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
        );

        final EditText mail = (EditText) findViewById(R.id.insertMail);
        mail.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    switch (keyCode) {
                        case KeyEvent.KEYCODE_ENTER:

                            if (isValidEmail(mail.getText())) {
                                mailPerson = mail.getText().toString();
                                billingRequest = new BillingRequest(cart, mailPerson);
                                deniedPaymentDialog();
                                delay();
                            } else {
                                Toast.makeText(getApplicationContext(), R.string.not_valid_email,
                                        Toast.LENGTH_LONG).show();
                            }
                            return true;
                        default:
                            break;
                    }
                }
                return false;
            }
        });


        ImageView goBackToCartArrow = (ImageView) findViewById(R.id.backToCartArrow);
        TextView goBackToCartText = (TextView) findViewById(R.id.backToCartText);

        goBackToCartArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchBackToCartActivity();
            }
        });
        goBackToCartText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchBackToCartActivity();
            }
        });
    }

    public void switchToEndPurchase(){
        Intent intentToEndPurchase= new Intent(this, EndPurchaseActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("emailCustomer", mailPerson);
        intentToEndPurchase.putExtras(bundle);
        startActivity(intentToEndPurchase);
    }

    public void switchBackToCartActivity(){
        super.onBackPressed();
    }

    public void sendXML(BillingRequest billingRequest){
        String xmlBillingRequest = null;
        XmlUtil xmlUtil = new XmlUtil(this);
        try {
            xmlBillingRequest = xmlUtil.writeXMLFile(billingRequest);
            XmlPostService xmlPostService = new XmlPostService(this.getApplicationContext(), xmlBillingRequest);
            xmlPostService.execute();
        }catch (IOException e){
            Log.e("ICanBuy", e.getMessage());
        }
        }

    public final boolean isValidEmail(CharSequence target) {
        if (target == null) {
            return false;
        } else {
            return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
        }
    }

    public void deniedPaymentDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(PaymentActivity.this);

        TextView titleDenied = new TextView(this);
        titleDenied.setText(R.string.denied_payment_title);
        titleDenied.setTextColor(getResources().getColor(R.color.icb_green));
        titleDenied.setGravity(Gravity.CENTER);
        titleDenied.setTextSize(30);
        builder.setView(titleDenied);

        TextView messageDenied = new TextView(this);
        messageDenied.setText(R.string.denied_payment_message);
        messageDenied.setGravity(Gravity.CENTER_HORIZONTAL);
        messageDenied.setTextSize(20);
        builder.setView(messageDenied);


        builder.setCustomTitle(titleDenied);
        builder.setPositiveButton(R.string.retry_button, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                succeedPaymentDialog();
                delay();
            }
        });
        alert = builder.create();
        alert.requestWindowFeature(Gravity.CENTER_VERTICAL);
        new BlurAsyncTask().execute();
    }

    public void succeedPaymentDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        TextView titleSucceed = new TextView(this);
        titleSucceed.setText(R.string.success_payment_title);
        titleSucceed.setTextColor(getResources().getColor(R.color.icb_green));
        titleSucceed.setGravity(Gravity.CENTER);
        titleSucceed.setTextSize(30);
        builder.setView(titleSucceed);

        TextView messageSucceed = new TextView(this);
        messageSucceed.setText(R.string.success_payment_message);
        messageSucceed.setGravity(Gravity.CENTER_HORIZONTAL);
        messageSucceed.setTextSize(20);
        builder.setView(messageSucceed);

        LinearLayout linear = new LinearLayout(this);
        linear.setBackgroundColor(getResources().getColor(R.color.icb_green));

        builder.setCustomTitle(titleSucceed);
        builder.setPositiveButton(R.string.continue_button, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                sendXML(billingRequest);
                switchToEndPurchase();
            }
        });
        alert = builder.create();
        alert.requestWindowFeature(Gravity.CENTER_VERTICAL);

        new BlurAsyncTask().execute();
}

    public void delay(){
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    class BlurAsyncTask extends AsyncTask<Void, Integer, Bitmap> {

        private  final String TAG = BlurAsyncTask.class.getName();

        protected Bitmap doInBackground(Void...arg0) {

            Bitmap map  = ScreenshotUtil.takeScreenShot(PaymentActivity.this);
            Bitmap fast = new BlurUtil().fastBlur(map, 10);

            return fast;
        }


        protected void onPostExecute(Bitmap result) {
            if (result != null){
                final Drawable draw=new BitmapDrawable(getResources(),result);
                Window window = alert.getWindow();
                window.setBackgroundDrawable(draw);
                window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
                window.setGravity(Gravity.CENTER);
                alert.show();

                TextView textView = (TextView) alert.findViewById(android.R.id.title);
                if (textView != null)
                    textView.setGravity(Gravity.CENTER);
            }

        }
    }
}
