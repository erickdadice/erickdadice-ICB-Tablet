package com.pernix.icanbuy.models;

import java.util.HashMap;

public class ProductList {

    private HashMap<String, Product> productList;

    public ProductList(){
        productList = new HashMap<String, Product>();
    }

    public ProductList(HashMap<String, Product> productList) {
        this.productList = productList;
    }

    public void setProductList(HashMap<String, Product> productList) {
        this.productList = productList;
    }

    public HashMap<String, Product> getProductList() {
        return productList;
    }

    public void addProduct(Product product){
        productList.put(String.valueOf(product.getIdProducto()), product);
    }

    public Product getProduct(String code){
        return productList.get(code);
    }
}
