package com.pernix.icanbuy.models.Carrito;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

import java.io.Serializable;

@Root
public class Carrito implements Serializable{
    @Element
    private int idCarrito;
    @Element
    private int idUsuario;
    @Element
    private double precio;
    @Element
    private double subtotal;
    @Element
    private String idProducto;



public Carrito(int idCarrito, int idUsuario, double precio, double subtotal, String idProducto){
    this.idCarrito = idCarrito;
    this.idUsuario = idUsuario;
    this.precio = precio;
    this.subtotal = subtotal;
    this.idProducto = idProducto;

}

public Carrito(){

}

    public int getIdCarrito() {
        return idCarrito;
    }

    public void setIdCarrito(int idCarrito) {
        this.idCarrito = idCarrito;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public String getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(String idProducto) {
        this.idProducto = idProducto;
    }
}

