package com.pernix.icanbuy.adapter;


import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.pernix.icanbuy.R;
import com.pernix.icanbuy.activities.CartActivity;
import com.pernix.icanbuy.fragments.ProductListFragment;
import com.pernix.icanbuy.models.CartItem;

import java.util.ArrayList;

public class CartItemAdapter extends BaseAdapter {

    private Fragment fragmentProductList;
    private ArrayList<CartItem> data;
    private Button buttonView;
    private Button buttonMore;


    public CartItemAdapter(Fragment fragment, ArrayList<CartItem> data){
        super();
        this.fragmentProductList = fragment;
        this.data = data;
    }

    public void addProduct(CartItem item) {
        data.add(item);
        notifyDataSetChanged();
    }

    public void removeProduct(CartItem item) {
        data.remove(item);
        notifyDataSetChanged();
    }

    public void updateProduct(){
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = fragmentProductList.getActivity().getLayoutInflater();

        ProductRowView rowView = new ProductRowView();

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.product_column_row, null);
            rowView.initializeTextViews(convertView);
            convertView.setTag(rowView);
        } else {
            rowView = (ProductRowView) convertView.getTag();

            final CartItem myItem = data.get(position);


            buttonView = (Button) convertView.findViewById(R.id.button_delete);
            buttonMore = (Button) convertView.findViewById(R.id.button_more);


            buttonView.setOnClickListener(new View.OnClickListener() {

          @Override
          public void onClick(View v) {
              CartActivity activity = (CartActivity) fragmentProductList.getActivity();
              activity.getPresenter().removeCartItem(myItem.getProduct().getIdProducto());
              notifyDataSetChanged();
          }
      });

            buttonMore.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    CartActivity activity = (CartActivity) fragmentProductList.getActivity();
                    activity.getPresenter().addCartItem((myItem.getProduct().getIdProducto()).toString());
                    notifyDataSetChanged();
                }
            });

        }
        CartItem item = data.get(position);
        rowView.setTextViewContent(item);



        return convertView;
    }
}
