package com.pernix.icanbuy.pagos;

import com.ingenico.connect.gateway.sdk.client.android.sdk.communicate.C2sCommunicatorConfiguration;
import com.ingenico.connect.gateway.sdk.client.android.sdk.session.Session;
import com.pernix.icanbuy.utils.PropertiesConfig;

public class GcSession {
    private PropertiesConfig propertiesConfig;
    String clientSessionId = "1";
    String customerId = "1";
    String clientApiUrl = propertiesConfig.getAirtableBaseUrl();
    String assetBaseUrl = propertiesConfig.getAirtableBaseUrl();
    boolean environmentIsProduction = false;
    String applicationIdentifier = "Example Application/v1";
    Session session = C2sCommunicatorConfiguration.initWithClientSessionId(
            clientSessionId,
            customerId,
            clientApiUrl,
            assetBaseUrl,
            environmentIsProduction,
            applicationIdentifier);

}
