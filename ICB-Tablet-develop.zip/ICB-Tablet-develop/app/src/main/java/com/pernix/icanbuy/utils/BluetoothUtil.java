package com.pernix.icanbuy.utils;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;
import com.pernix.icanbuy.BuildConfig;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Auxiliary methods
 * Credits: Created by sash0k on 29.01.14.
 */

public class BluetoothUtil {

    private static final String TAG = "BluetoothUtils";
    private static final boolean occur = true;

    /**
     * see http://habrahabr.ru/post/144547/
     */
    public static BluetoothSocket createRfcommSocket(BluetoothDevice device) {
        BluetoothSocket temporal = null;
        try {
            Class deviceClass = device.getClass();
            Class aclass[] = new Class[1];
            aclass[0] = Integer.TYPE;
            Method method = deviceClass.getMethod("createRfcommSocket", aclass);
            Object aobj[] = new Object[1];
            aobj[0] = Integer.valueOf(1);

            temporal = (BluetoothSocket) method.invoke(device, aobj);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            if (occur) Log.e(TAG, "createRfcommSocket() failed", e);
        } catch (InvocationTargetException e) {
            e.printStackTrace();
            if (occur) Log.e(TAG, "createRfcommSocket() failed", e);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
            if (occur) Log.e(TAG, "createRfcommSocket() failed", e);
        }
        return temporal;
    }

    /**
     * The general method of output debugging messages to the log
     */
    public static void log(String message) {
        if (BuildConfig.DEBUG) {
            if (message != null) Log.i(TAG, message);
            System.out.println("Log " + message);
        }
    }

    /**
     * Convert hex-string teams to display
     * Translation imposed ASCII-command to hex byte.
     * param Hex - team
     * return - An array of bytes team
     */
    public static String printHex(String hex) {
        StringBuilder sb = new StringBuilder();
        int lengthHex = hex.length();
        try {
            for (int i = 0; i < lengthHex; i += 2) {
                sb.append("0x").append(hex.substring(i, i + 2)).append(" ");
            }
        } catch (NumberFormatException e) {
            log("printHex NumberFormatException: " + e.getMessage());

        } catch (StringIndexOutOfBoundsException e) {
            log("printHex StringIndexOutOfBoundsException: " + e.getMessage());
        }
        return sb.toString();
    }

    /**
     * Convert string to hex
     */
    public static byte[] toHex(String hex) {
        int lengthString = hex.length();
        byte[] result = new byte[lengthString];
        try {
            int index = 0;
            for (int position = 0; position < lengthString; position += 2) {
                result[index] = (byte) Integer.parseInt(hex.substring(position, position + 2), 16);
                index++;
            }
        } catch (NumberFormatException e) {
            log("toHex NumberFormatException: " + e.getMessage());

        } catch (StringIndexOutOfBoundsException e) {
            log("toHex StringIndexOutOfBoundsException: " + e.getMessage());
        }
        return result;
    }

    /**
     * The method merges two arrays into one
     */
    public static byte[] concat(byte[] firstByte, byte[] secondByte) {
        byte[] result = new byte[firstByte.length + secondByte.length];
        System.arraycopy(firstByte, 0, result, 0, firstByte.length);
        System.arraycopy(secondByte, 0, result, firstByte.length, secondByte.length);
        return result;
    }

    /**
     * Getting id saved in the game sound set
     *
    public static String getPrefence(Context context, String item) {
        final SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(context);
        return settings.getString(item, TAG);
    }
    */

    /**
     * Receiving the flag of the settings
     */
    public static boolean getBooleanPrefence(Context context, String tag) {
        final SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(context);
        return settings.getBoolean(tag, true);
    }
}
