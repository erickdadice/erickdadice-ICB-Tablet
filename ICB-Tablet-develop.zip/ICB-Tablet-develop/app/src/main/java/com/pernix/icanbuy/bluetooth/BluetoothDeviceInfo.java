package com.pernix.icanbuy.bluetooth;

import android.bluetooth.BluetoothDevice;


public class BluetoothDeviceInfo {

    private String name;
    private String address;
    private int bondState;
    private final int deviceClass;
    private final int majorDeviceClass;

    public BluetoothDeviceInfo(BluetoothDevice device, String emptyName) {
        name = device.getName();
        address = device.getAddress();
        bondState = device.getBondState();

        if (name == null || name.isEmpty()) {
            name = emptyName;
        }
        deviceClass = device.getBluetoothClass().getDeviceClass();
        majorDeviceClass = device.getBluetoothClass().getMajorDeviceClass();
    }

    public String getName() {
        return name;
    }

    public void setName(String deviceName) {
        name = deviceName;
    }

    public String getAddress() {
        return address;
    }

}
