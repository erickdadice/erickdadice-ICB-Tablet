package com.pernix.icanbuy.models.DetalleFactura;

import org.simpleframework.xml.Element;

import java.io.Serializable;
import java.util.Date;

public class DetalleFactura implements Serializable {
    @Element
    private int IdDetalle;

    @Element
    private int IdFactura;

    @Element
    private String IdProducto;

    @Element
    private Double CantidadComprada;

    @Element
    private Double Precio;

    @Element
    private String Gravado;

    @Element
    private Double Subtotal;

    public void setIdProducto(String idProducto) {
        IdProducto = idProducto;
    }

    public DetalleFactura() {
    }

    public int getIdDetalle() {
        return IdDetalle;
    }

    public void setIdDetalle(int idDetalle) {
        this.IdDetalle = idDetalle;
    }

    public int getIdFactura() {
        return IdFactura;
    }

    public void setIdFactura(int idFactura) {
        this.IdFactura = idFactura;
    }

    public String getIdProducto() {
        return IdProducto;
    }

    public Double getCantidadComprada() {
        return CantidadComprada;
    }

    public void setCantidadComprada(Double cantidadComprada) {
        this.CantidadComprada = cantidadComprada;
    }

    public Double getPrecio() {
        return Precio;
    }

    public void setPrecio(Double precio) {
        this.Precio = precio;
    }

    public String getGravado() {
        return Gravado;
    }

    public void setGravado(String gravado) {
        this.Gravado = gravado;
    }

    public Double getSubtotal() {
        return Subtotal;
    }

    public void setSubtotal(Double subtotal) {
        this.Subtotal = subtotal;
    }
}
