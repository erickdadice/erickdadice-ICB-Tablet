package com.pernix.icanbuy.activities;

public class Constants {
    public static String AIRTABLE_API_KEY = "keyxRTI7RCths7PQp";
    public static String AIRTABLE_BASE_URL = "https://api.airtable.com/v0/appPvM705sztvANQP/";
}
