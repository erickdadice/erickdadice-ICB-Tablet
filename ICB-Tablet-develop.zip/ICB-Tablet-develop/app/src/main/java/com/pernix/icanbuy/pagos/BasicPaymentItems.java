package com.pernix.icanbuy.pagos;

public class BasicPaymentItems {

}
