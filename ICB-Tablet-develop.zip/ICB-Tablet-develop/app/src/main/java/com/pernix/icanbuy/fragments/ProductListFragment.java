package com.pernix.icanbuy.fragments;


import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;

import com.pernix.icanbuy.R;
import com.pernix.icanbuy.adapter.CartItemAdapter;
import com.pernix.icanbuy.models.CartItem;

import java.util.ArrayList;

public class ProductListFragment extends Fragment {

    private ArrayList<CartItem> data;
    private ListView listView;
    private CartItemAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_product_list, container, false);
        listView = (ListView) view.findViewById(R.id.product_listview);
        data = new ArrayList<CartItem>();
        adapter = new CartItemAdapter(this, data);
        listView.setAdapter(adapter);
        return view;
    }

    public void notifyProductChange(){
        adapter.updateProduct();
    }

    public void addProduct(CartItem item) {
        adapter.addProduct(item);
    }

    public void removeProduct(final CartItem item) {
        adapter.removeProduct(item);
    }


}
