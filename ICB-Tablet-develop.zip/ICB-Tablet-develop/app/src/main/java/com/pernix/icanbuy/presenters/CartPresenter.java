package com.pernix.icanbuy.presenters;


import android.content.Context;
import android.widget.Toast;

import com.pernix.icanbuy.models.Cart;
import com.pernix.icanbuy.models.CartItem;
import com.pernix.icanbuy.models.Product;
import com.pernix.icanbuy.services.DALService;

import static com.pernix.icanbuy.constants.CartConstant.PRODUCT_NOT_FIND_MESSAGE;


public class CartPresenter {


    private Cart cart;
    private CartObserver observer;
    private DALService firebaseService;
    private Context context;

    public CartPresenter(DALService firebaseService, Context context) {
        this.cart = null;
        this.cart = new Cart();
        this.context= context;
        this.firebaseService = firebaseService;
    }

    public void addObserver(CartObserver observer) {
        this.observer = observer;
    }

    public Cart getCart() {
        return cart;
    }

    public Product getProductFromFirebase(String productCode){
        return firebaseService.getProductByCode(productCode);
    }

    public boolean cartHasItems(){
        return (cart.getCartSize() > 0);
    }

    public double getCartTotal(){
        return cart.getCartTotal();
    }

    public void addCartItem(final String code) {

        Product product = getProductFromFirebase(code);

        if(product != null) {
            CartItem item = cart.getCartItemByCode(product.getIdProducto());
            if (item != null) {
                item.setQuantity(item.getQuantity() + 1);
                cart.setCartTotal(cart.getCartTotal() + item.getProduct().getPrecio());
               // cart.addItem(item);
                observer.notifyUpdateProduct();
            } else {
                createCartItem(product);
            }
        }else{
           // Toast.makeText(context, PRODUCT_NOT_FIND_MESSAGE, Toast.LENGTH_SHORT).show();
        }
    }

    public void removeCartItem(final Long code) {

        CartItem item = cart.getCartItemByCode(code);

        if (item != null) {
            cart.removeItem(item);
            cart.setCartTotal(cart.getCartTotal() - item.getProduct().getPrecio());
            observer.notifyRemoveProduct(item);
        }
    }

    private void createCartItem(Product product) {
        CartItem item;
        if (cartHasItems()) {
            item = cart.createNewItem(product);
            cart.setCartTotal(cart.getCartTotal() + item.getProduct().getPrecio());
            observer.notifyNewProduct(item);
        } else {
            item = cart.createNewItem(product);
            cart.setCartTotal(item.getProduct().getPrecio());
            observer.notifyFirstTime(item);
        }
    }
}