package com.pernix.icanbuy.models.Supermercado;

import com.pernix.icanbuy.models.Carrito.CarritoFields;

import java.util.HashMap;
import java.util.Map;

public class SupermercadoRecord {
    private String id;
    private CarritoFields fields;
    private String createdTime;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public CarritoFields getFields() {
        return fields;
    }

    public void setFields(CarritoFields fields) {
        this.fields = fields;
    }

    public String getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(String createdTime) {
        this.createdTime = createdTime;
    }

    public Map<String, Object> getAdditionalProperties() {
        return additionalProperties;
    }

    public void setAdditionalProperties(Map<String, Object> additionalProperties) {
        this.additionalProperties = additionalProperties;
    }
}
